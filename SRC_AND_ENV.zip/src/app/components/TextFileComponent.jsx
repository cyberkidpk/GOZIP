import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Image,
  Text,
  TextInput,
  Form,
  TextArea,
  FormField,
  Button,
  Spinner,
  RadioButtonGroup,
  Layer,
} from 'grommet'
export { TextFileComponent }

function TextFileComponent({ isEdit, fileContent, onCallbackSubmit}) {
const [value1, setValue1] = React.useState(fileContent);
   return (
   <Box width="100%" height="100%">
    <TextArea
      value={value1}
      onChange={event => setValue1(event.target.value)}
    />
   <Button primary label={isEdit ? "Overwrite" :"Submit"} onClick={()=>{
   onCallbackSubmit(value1)
   }
   } />
    </Box>
  );
        }