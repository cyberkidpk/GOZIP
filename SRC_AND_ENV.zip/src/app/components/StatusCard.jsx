import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Image,
  Text,
  TextInput,
  // Form,
  FormField,
  Button,
  Spinner,
  RadioButtonGroup,
  Layer,
} from 'grommet'
export { StatusCard }

function StatusCard({onboardingStatus:obs}) {
var { step, isFolderStructureExist, color , title} = obs;
var [onboardingStatus, setOnboardingStatus]= useState({ step, isFolderStructureExist, color, title})
useEffect(()=>{
onboardingStatus.step= step;
onboardingStatus.isFolderStructureExist=isFolderStructureExist;
onboardingStatus.color=(isFolderStructureExist === 'InProgress') ? 'orange': color;
onboardingStatus.title=["Project Folder", "Project Configuration folder","Project YAML file", "DEV, QA and PROD reference"];
setOnboardingStatus(onboardingStatus)
}, [step, isFolderStructureExist, color, title])
return(<Card
          width="800px"
          height="300px"
          background="#0d1c2a"
          margin={'20px'}
          align="center"
          justify="center"
        >
          <CardHeader><h1 style={{color:`${color}`}}>Step: {onboardingStatus.step}</h1> </CardHeader>
          <CardBody align="center" justify="center">
               {onboardingStatus.title[step-1]}
            {onboardingStatus.isFolderStructureExist == 'failed' ? 'FAILED' : ''}
            {onboardingStatus.isFolderStructureExist !== 'failed' ? (
              <h1 style={{color:`${color}`}}>
                Success
              </h1>
            ) : (
              <Spinner
                color={onboardingStatus.isFolderStructureExist == 'failed' ? `${onboardingStatus.color}` : `${onboardingStatus.color}`}
                size="large"
              ></Spinner>
            )}
          </CardBody>
          <CardFooter></CardFooter>
        </Card>
        )
        }