import axios from 'axios'
import { Button, Text, Box} from 'grommet'
import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import { CONSTANTS } from '../../constants-and-configs'

export function TriggerPipelineComponent({
  project_id = '',
  inProgress = undefined,
  targetBranchName = 'abbvie_emr_chg000001',
  project_name = 'abbvie_emr',
  isPipelineExist = false,
  result
}) {
 const targetRepoName = 'CommercialDatalake-market-access'
  const targetRepoId = 'f2088e90-a063-4621-ab89-a3afe49cf1c5'
 targetBranchName = 'abbvie_emr_chg000001'
  project_id = '2df205f6-df0d-4b64-a398-63fdccc58939'
  project_name = 'data_onboarding_utility_project'
  const [triggerOrNoTrigger, setTriggerOrNoTrigger] = useState([])
  const triggerPipeline = async () => {
  let endpoint =''
  let repoParam;
  if(!isPipelineExist){
  endpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}/_apis/pipelines?api-version=7.0`
  repoParam ={
  configuration:{
     type: 'yaml',
	"path":"/src/abbvie_emr/configuration/cdl-market-access-build-abbvie-emr-configuration.yml",
	"repository":{
     "id":targetRepoId,
	"type":"AzureReposGit",
	"name":targetRepoName,
	"defaultBranch":"refs/heads/"+targetBranchName,
},
	},


}

  }else{
    //endpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}/_apis/pipelines/1/runs?pipelineVersion=1&api-version=7.0`;
  endpoint =`${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}/_apis/pipelines/12/runs?pipelineVersion=1&api-version=7.0`

  repoParam = {

    resources: {

    repositories: {
          self: {
          repository:{
          "id":targetRepoId,
          "type":"AzureReposGit",
          "name":targetRepoName,
          },
            "refName":"refs/heads/"+targetBranchName,

        },
        }

      },

    }
    }

    // /src/${project_name}/configuration
    if (project_id) {
      try {
      console.log("repoParam", repoParam)
        const response = await axios.post(endpoint, repoParam)
        console.log(response)
        setTriggerOrNoTrigger(response)
        setTimeout(() => {
         // window.location.href = '/projects-and-pipelines'
        }, 400)
      } catch {
      alert("PIPELINE TO RUN");
        setTriggerOrNoTrigger([])
      }
    }
  }

  useEffect(() => {
    setTriggerOrNoTrigger(!triggerOrNoTrigger.length ? [1] : triggerOrNoTrigger)
  }, [triggerOrNoTrigger])
  return (
    <>
      {inProgress !== 'inProgress' ? (
      <Box direction="row">
        <Button
          style={{ padding: '10px', margin: '6px', width:"200px", fontSize:"10px" }}
          primary
          onClick={() => {
            triggerPipeline()
          }}
          label={result === "succeeded" ? "RE-TRIGGER THE PIPELINE":  "TRIGGER THE PIPELINE"}
        />
        {result === "succeeded" ? <Button label="RAISE THE PULL REQUEST" style={{ padding: '10px', margin: '6px', width:"200px", fontSize:"10px", color:"white", background:"green"  }} /> :""}
        </Box>
      ) : (


          <Text color="green"> PIPELINE IS IN PROGRESS - PLEASE WAIT</Text>


      )}
    </>
  )
}
