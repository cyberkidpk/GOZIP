import axios from 'axios'
import {
  Accordion,
  AccordionPanel,
  Anchor,
  Box,
  Spinner,
  Text,
  Button,
} from 'grommet'
import react, { useState } from 'react'
import { useEffect } from 'react'
import { APP_CONFIG, CONSTANTS } from '../../constants-and-configs'
import { TriggerPipelineComponent } from './PipelineTriggerComponent'

const BoxComponent = ({ project_id = null, project_name = '' }) => {
  const [pipelinesLocal, setPipelinesLocal] = useState([])
  const [prmFileStatusLocal, setPrmFileStatusLocal] = useState('')

  const prmFileStatus = (targetBranchName) => {
    const isPRMFileUrl = `${
      CONSTANTS.APIS.DEV_OPS_BASE_URL
    }/${project_id}/_apis/sourceProviders/TfsGit/filecontents?repository=${project_name.replace(
      'project',
      'repo',
    )}&commitOrBranch=${targetBranchName}&path=${project_name}_sqoop.prm&api-version=7.0`
    axios.get(isPRMFileUrl).then(
      (isPRMResp) => {
        const { data: prmresp } = isPRMResp
        setPrmFileStatusLocal('exist')
      },
      (errorresp) => {
        console.log('ERROR RESPONSE', errorresp)
        setPrmFileStatusLocal('error')
      },
    )
  }

  useEffect(() => {
    if (project_id) {
      const pipelineEndpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}${CONSTANTS.APIS.GET_SUFFIX.PIPELINES}`
      const statusApiEndpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}/_apis/pipelines/12/runs?api-version=6.0-preview.1`
      function getPipelines() {
        return axios.get(pipelineEndpoint)
      }
      function getStatuses() {
        return axios.get(statusApiEndpoint)
      }

      Promise.all([getPipelines(), getStatuses()]).then(function (results) {
        const pipelines = results[0]
        const statuses = results[1]

        console.log('pipeline', pipelines)

        const mergedData = [pipelines, statuses]
        console.log('statuses', mergedData)
        setPipelinesLocal(mergedData)
       // prmFileStatus()
      })
    }
  }, [project_id, pipelinesLocal.length])
  return project_id && pipelinesLocal && pipelinesLocal.length ? (
    <Box>
      <Box
        className="sec-config"
        background="#ccefef"
        direction="row"
        style={{ width: '100%' }}
      >
        <Box width="65%"></Box>
        <Box
          primary
          style={{
            fontSize: '1.1rem',
          }}
          width="35%"
        >
          {pipelinesLocal[0]?.data ?
                <TriggerPipelineComponent
                   isPipelineExist
                  inProgress={pipelinesLocal[1]?.data.value[0].state}
                  project_id={project_id}
                  result={pipelinesLocal[1]?.data.value[0].result}
                ></TriggerPipelineComponent> :
                <TriggerPipelineComponent
                    isPipelineExist={false}
                  inProgress={pipelinesLocal[1]?.data.value[0].state}
                  project_id={project_id}
                ></TriggerPipelineComponent>
                }
        </Box>
      </Box>
      <Box
        pad="medium"
        background="light-2"
        justify="space-between"
        align="center"
        direction="row"
      >
        <Text size="small" width="320px">
          <strong>{`Pipeline Revision Id:`}</strong>
          <br />
          <h1>{`${pipelinesLocal[1]?.data.value[0].pipeline.revision}`}</h1>
        </Text>
        <Text size="small" width="320px">
          <strong>{`Repo Name:`}</strong>
          <br />
          {`${pipelinesLocal[0]?.data.value[0].name.replace(/_/g, '  ')}`}
        </Text>
        <Text size="small" width="320px">
          <strong>{`Pipeline Created Date:`}</strong>
          <br />
          {`${new Date(
            pipelinesLocal[1]?.data.value[0].createdDate,
          ).toLocaleDateString('en-US')}`}
        </Text>
        <Text size="small" width="320px">
          <strong>{`Pipeline Finished Date:`}</strong>
          <br />
          {`${new Date(
            pipelinesLocal[1]?.data.value[0].finishedDate,
          ).toLocaleDateString('en-US')}`}
        </Text>
        <Text size="small" width="320px">
          <Box justify="center" align="center" direction="column">
            <Text>
              <strong>{`Pipeline State:`}</strong>
            </Text>

            {pipelinesLocal[1]?.data.value[0].state === 'inProgress' ? (
              <Spinner size="medium" color="green"></Spinner>
            ) : pipelinesLocal[1]?.data.value[0].state == 'completed' ? (
              <Text size="large">✅</Text>
            ) : (
              ''
            )}
            <h5
              style={{ color: '#b90351' }}
            >{`${pipelinesLocal[1]?.data.value[0].state}`}</h5>
          </Box>
        </Text>
        <Text size="small" width="320px">
          <Box justify="center" align="center" direction="column">
            <Text>
              <strong>{`Pipeline Result:`}</strong>
            </Text>

            {pipelinesLocal[1]?.data.value[0].result === 'succeeded' ? (
              <Text size="large">✅</Text>
            ) : (
              ''
            )}
            <h5
              style={{ color: '#b90351' }}
            >{`${pipelinesLocal[1]?.data.value[0].result}`}</h5>
          </Box>
        </Text>
      </Box>
    </Box>
  ) : (
    <Box pad="medium" background="white" justify="center" align="center">
      <Spinner size="large" />
    </Box>
  )
}
const PanelComponents = ({ projects = [] }) => {
  return projects.map((proPanel) => {
    const { name, id } = proPanel
    return (
      <Box className="go-col-text">
        <AccordionPanel
          style={{ background: '#dddada' }}
          label={`Project name: ${name} - ☛	☛ toggle Open and close for Refeshed statuses `}
          color={'blue'}
          width="1390px"
        >
          <BoxComponent project_id={id} project_name={name}></BoxComponent>
        </AccordionPanel>
      </Box>
    )
  })
}
const DIUAccordion = ({ data = [] }) => {
  const [proData, setProData] = useState(data)
  useEffect(() => {
    setProData(data)
  }, [data])
  return (
    <Accordion>
      <PanelComponents projects={proData} />
    </Accordion>
  )
}

export { DIUAccordion, PanelComponents, BoxComponent }
