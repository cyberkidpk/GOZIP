import axios from 'axios'
import {
  Accordion,
  AccordionPanel,
  Anchor,
  Box,
  Spinner,
  Text,
  Button,
} from 'grommet'
import react, { useState } from 'react'
import { useEffect } from 'react'
import { APP_CONFIG, CONSTANTS } from '../../constants-and-configs'
import { TriggerPipelineComponent } from './PipelineTriggerComponent'
const targetRepoName = 'CommercialDatalake-market-access'
const BoxComponent = ({ project_id = null, project_name = '' }) => {
  const [pipelinesLocal, setPipelinesLocal] = useState([])
  const [prmFileStatusLocal, setPrmFileStatusLocal] = useState('')

  const prmFileStatus = (targetBranchName) => {
    const isPRMFileUrl = `${
      CONSTANTS.APIS.DEV_OPS_BASE_URL
    }/${project_id}/_apis/sourceProviders/TfsGit/filecontents?repository=${project_name.replace(
      'project',
      'repo',
    )}&commitOrBranch=${targetBranchName}&path=${project_name}_sqoop.prm&api-version=7.0`
    axios.get(isPRMFileUrl).then(
      (isPRMResp) => {
        const { data: prmresp } = isPRMResp
        setPrmFileStatusLocal('exist')
      },
      (errorresp) => {
        console.log('ERROR RESPONSE', errorresp)
        setPrmFileStatusLocal('error')
      },
    )
  }

  useEffect(() => {
    if (project_id) {
      const pipelineEndpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}${CONSTANTS.APIS.GET_SUFFIX.PIPELINES}`
      const statusApiEndpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${project_id}/_apis/pipelines/1/runs?api-version=6.0-preview.1`
      function getPipelines() {
        return axios.get(pipelineEndpoint)
      }
      function getStatuses() {
        return axios.get(statusApiEndpoint)
      }

      Promise.all([getPipelines(), getStatuses()]).then(function (results) {
        const pipelines = results[0].data.value.filter(obj=>{
        console.log(obj.name);
        return obj.name === targetRepoName
        })
        console.log("pipelines", pipelines);
        const statuses = results[1]

        console.log('pipeline', pipelines)

        const mergedData = [pipelines, statuses]
        console.log('statuses', mergedData)
        setPipelinesLocal(mergedData)
       // prmFileStatus()
      })
    }
  }, [project_id, pipelinesLocal.length])
  return  pipelinesLocal && pipelinesLocal.length === 2 && pipelinesLocal[0].length ? (<Box width="100%">

           <Text color="green">PROJECT REPO FOUND</Text>

          </Box>) :
          (<Box width="100%">


           <Text color="red">PIPELINE CREATED, TRIGGER FIRST PIPELINE</Text>
           <TriggerPipelineComponent project_id={project_id} />

          </Box>)
}
const PanelComponents = ({ projects = [] }) => {
  return projects.map((proPanel) => {
    const { name, id } = proPanel
    return (
      <Box className="go-col-text">
        <AccordionPanel
          style={{ background: '#dddada' }}
          label={`Project name: ${name} - ☛	☛ toggle Open and close for Refeshed statuses `}
          color={'blue'}
          width="1390px"
        >
          <BoxComponent project_id={id} project_name={name}></BoxComponent>
        </AccordionPanel>
      </Box>
    )
  })
}
const DIUAccordion = ({ data = [] }) => {
  const [proData, setProData] = useState(data)
  useEffect(() => {
    setProData(data)
  }, [data])
  return (
    <Accordion>
      <PanelComponents projects={proData} />
    </Accordion>
  )
}

export { DIUAccordion, PanelComponents, BoxComponent }
