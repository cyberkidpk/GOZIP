import _ from 'lodash'

const validateFile = (filename, {startWith, mustHave, endWith, ext, format}) => {
  const splitted = filename?.split('.')
  if (splitted[splitted.length - 1] !== ext) {
    return 'Invalid file format. Please check file format i.e-' + ' ' + format
  }
  if (filename.indexOf('_' + mustHave + '_') === -1) {
    return (
      'File name must have the project name. Please check file format i.e-' +
      ' ' +
      format
    )
  }

  if (startWith && !_.startsWith(splitted[0],startWith)) {
      return 'Invalid file name. Please check file format i.e-' + ' ' + format
  }
  if (endWith && !(_.endsWith(splitted[0],endWith, splitted[0].length))) {
      return 'Invalid file name. Please check file format i.e-' + ' ' + format
  }
  return true
}

const checkDuplicateFileName = (node, fileName, fileId) => {
  let isDuplicate = false
  const files = node.files
  files.forEach((obj) => {
    if (obj.name === fileName.trim() && obj.id !== fileId) {
      isDuplicate = true
      return
    }
  })
  return isDuplicate
}

export const validateFileByFolderName = (node, fileName, fileId) => {
  let  isValid = validateFile(fileName, {...node.fileFormat})
    if (isValid === true) {
    const duplicatedFileName = checkDuplicateFileName(node, fileName,fileId)
    if (duplicatedFileName) {
      isValid = 'Duplicate file name.'
    }
  }
  console.log('isValid', isValid)
  return isValid
//    console.log(fileName+"sd"+fileId)
//  let isValid
//  let projectName = ''
//  // get project name
//  function getProjectName(node) {
//    if (node.name !== 'configuration') {
//      getProjectName(node.parentNode)
//    } else {
//      projectName = node.parentNode.name
//    }
//  }
//  getProjectName(node)
//
//  let parentFolderName = node.name
//
//  //get the parent folder name to validate file format
//  function checkParentFolder(node, folderName, projectName) {
//

//    if (
//      FOLDER_LIST.indexOf(folderName) === -1 &&
//      projectName.toLocaleUpperCase() !== folderName
//    ) {
//      checkParentFolder(
//        node.parentNode,
//        node.parentNode.name.toLocaleUpperCase(),
//        projectName,
//      )
//    } else {
//      parentFolderName = folderName
//    }
//  }
//
//  if(LEVEL_2_FOLDER_LIST.indexOf(parentFolderName) === -1){ //check if folder name (dev/qa/prod)
//    checkParentFolder(node, parentFolderName, projectName)
//  }
//
//
//  if (parentFolderName == FILE_FORMAT.AUTOSYSJOBRUN.name) {
//    let { ext, format, endWith } = FILE_FORMAT.AUTOSYSJOBRUN
//    isValid = validateFile(fileName, ext, format, projectName, endWith)
//  } else if (parentFolderName == FILE_FORMAT.CONFIG.name) {
//    let { ext, format, startWith, endWith } = FILE_FORMAT.CONFIG
//    isValid = validateFile(
//      fileName,
//      ext,
//      format,
//      projectName,
//      startWith,
//      endWith,
//    )
//  } else if (parentFolderName == FILE_FORMAT.PROPERTIES.name) {
//    let { ext, format, endWith } = FILE_FORMAT.PROPERTIES
//    isValid = validateFile(fileName, ext, format, projectName, endWith)
//  } else if (parentFolderName == FILE_FORMAT.SCHEMA.name) {
//    let { ext, format, endWith } = FILE_FORMAT.SCHEMA
//    isValid = validateFile(
//      fileName,
//      ext,
//      format,
//      projectName,
//      endWith,
//      parentFolderName,
//    )
//  } else if (parentFolderName == FILE_FORMAT.STATIC_FILES) {
//    isValid = true
//  } else if (node.name == LEVEL_2_FOLDER_LIST[0]) { //check for dev
//    let { ext, format, endWith } = FILE_FORMAT.WORKFLOW_JSON
//    isValid = validateFile(fileName, ext, format, projectName, endWith)
//  } else {
//    isValid = true
//  }


}
