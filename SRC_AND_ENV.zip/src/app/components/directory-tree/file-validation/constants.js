const FILE_FORMAT = {
    AUTOSYSJOBRUN:{
        name:'autosysjobrun',
        startWith:'',
        mustHave:'projectName',
        endWith:'_move_script',
        ext:'properties',
        format:'YOUR-STRING_{project-name}_YOUR-STRING_move_script.properties , _{project-name}_ could be _mhcdm_emr_'
    },
    CONFIG:{
        name:'config',
        startWith:'env_config_',
        mustHave:'projectName',
        endWith:'_tbl',
        ext:'json',
        format:'env_config_YOUR-STRING_{project-name}_tbl.json, _{project-name}_ could be _mhcdm_emr_'
    },
    PROPERTIES:{
        name:'properties',
        startWith:'',
        mustHave:'projectName',
        endWith:'_tbl',
        ext:'json',
        format:'YOUR-STRING_{project-name}_tbl.json, _{project-name}_ could be _mhcdm_emr_'
    },
    SCHEMA:{
        name:'SCHEMA',
        startWith:'',
        mustHave:'projectName',
        endWith:'_tbl_',
        ext:'txt',
        format:'YOUR-STRING_{project-name}_tbl_parent-folder.txt, _{project-name}_ could be _mhcdm_emr_'
    },
    STATIC_FILES:{
        name:'staticfiles'
    },

    WORKFLOW_JSON:{
        name:'WORKFLOW JSON',
        startWith:'',
        mustHave:'projectName',
        endWith:'_workflow',
        ext:'json',
        format:'YOUR-STRING_{project-name}_workflow.json,  _{project-name}_ could be _mhcdm_emr_'
    }
}

const FOLDER_LIST = ['autosysjobrun', 'config', 'parameters','properties','staticfiles', 'listfiles', 'schema']
const LEVEL_1_FOLDER_LIST =['configuration']
const LEVEL_2_FOLDER_LIST =['dev', 'qa','prod']

export {FILE_FORMAT, FOLDER_LIST, LEVEL_2_FOLDER_LIST}