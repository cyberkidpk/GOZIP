import React, { useState, useEffect } from 'react'
import {
  AiOutlineFolderAdd,
  AiOutlineFileAdd,
  AiOutlineFolder,
  AiOutlineFolderOpen,
  AiOutlineDelete,
  AiOutlineEdit,
} from 'react-icons/ai'

import {
  ActionsWrapper,
  Collapse,
  StyledName,
  VerticalLine,
} from '../Tree.style'
import { StyledFolder } from './TreeFolder.style'

import { FILE, FOLDER } from '../state/constants'
import { useTreeContext } from '../state/TreeContext'
import { PlaceholderInput } from '../TreePlaceholderInput'
import { validateFileByFolderName } from '../../file-validation/file-validation'

const FolderName = ({ isOpen, name, handleClick }) => (
  <StyledName onClick={handleClick}>
    {isOpen ? <AiOutlineFolderOpen /> : <AiOutlineFolder />}
    &nbsp;&nbsp;{name}
  </StyledName>
)

const Folder = ({ id, name, children, node }) => {
  const { dispatch, isImparative, onNodeClick } = useTreeContext()
  const [isEditing, setEditing] = useState(false)
  const [isOpen, setIsOpen] = useState(false)
  const [childs, setChilds] = useState([])


  useEffect(() => {
    setChilds([children])
  }, [children])

  const commitFolderCreation = (name) => {
    dispatch({ type: FOLDER.CREATE, payload: { id, name } })
  }

  const commitFileCreation = (name) => {
    let validFile = validateFileByFolderName(node, name, id)
    if (validFile === true) {
      dispatch({ type: FILE.CREATE, payload: { id, name } })
    } else {
      alert(validFile)
      console.log('validFile', validFile)
    }
  }
  const commitDeleteFolder = () => {
    dispatch({ type: FOLDER.DELETE, payload: { id } })
  }
  const commitFolderEdit = (name) => {
    dispatch({ type: FOLDER.EDIT, payload: { id, name } })
    setEditing(false)
  }

  const handleCancel = () => {
    setEditing(false)
    setChilds([children])
  }

  const handleNodeClick = React.useCallback(
    (event) => {
      event.stopPropagation()
      onNodeClick({ node })
    },
    [node],
  )

  const handleFileCreation = (event) => {
    event.stopPropagation()
    setIsOpen(true)
    setChilds([
      ...childs,
      <PlaceholderInput
        type="file"
        onSubmit={commitFileCreation}
        onCancel={handleCancel}
      />,
    ])
  }

  const handleFolderCreation = (event) => {
    event.stopPropagation()
    setIsOpen(true)
    setChilds([
      ...childs,
      <PlaceholderInput
        type="folder"
        onSubmit={commitFolderCreation}
        onCancel={handleCancel}
      />,
    ])
  }

  const handleFolderRename = () => {
    setIsOpen(true)
    setEditing(true)
  }

  return (
    <StyledFolder id={id} onClick={handleNodeClick} className="tree__folder">
      <VerticalLine>
        <ActionsWrapper>
          {isEditing ? (
            <PlaceholderInput
              type="folder"
              style={{ paddingLeft: 0 }}
              defaultValue={name}
              onCancel={handleCancel}
              onSubmit={commitFolderEdit}
            />
          ) : (
            <FolderName
              name={name}
              isOpen={isOpen}
              handleClick={() => setIsOpen(!isOpen)}
            />
          )}

          {isImparative && node?.hasPermission && (
            <div className="actions">
             { node.permissible.includes('toggleEdit') ? <AiOutlineEdit onClick={handleFolderRename} /> : ''}
             { node.permissible.includes('add') ?  <AiOutlineFileAdd onClick={handleFileCreation} /> : ''}
             { node.permissible.includes('delete') ? <AiOutlineDelete onClick={commitDeleteFolder} /> : ''}
            </div>
          )}
        </ActionsWrapper>
        <Collapse className="tree__folder--collapsible" isOpen={isOpen}>
          {childs}
        </Collapse>
      </VerticalLine>
    </StyledFolder>
  )
}

export { Folder, FolderName }
