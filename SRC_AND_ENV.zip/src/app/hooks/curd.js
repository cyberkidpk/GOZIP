// use-fetch-data.js
import { useEffect, useState} from 'react';
import axios from 'axios';
const useFetchData = (method, url, config) => {
  const [data, setData] = useState({});
  const [apiError, setApiError] = useState(null);
  const [loading, setLoading] = useState(true);
 // 7imqmsyfz5uqjfh3bo7pnt4vj44kf3rspor6o6rfe2bz7qeccpna
  const token = '7imqmsyfz5uqjfh3bo7pnt4vj44kf3rspor6o6rfe2bz7qeccpna';
  //window.localStorage.getItem("access_token")
  

  let configHead = {};
  if (token){
    axios.defaults.headers.common = {
      'Authorization': 'Basic ' + btoa("" + ":" + token)
  }
  }
  useEffect(() => {
    const fetchData = async () => {
      config = config ? config : {};
      try {
        const { data } = await axios[method](url, config);
        console.log("responseresponse response responseresponseresponseresponse", data)
        setData(data);
      } catch (error) {
        console.error("errorerrorerrorerrorerrorerrorerrorerrorerrorerrorerroreresponseresponseresponserror")
        console.error(error)
        setApiError(error)
      }
      setLoading(false);
    };
    fetchData();
  }, []);
  return {
    data,
    loading,
    apiError
  };
};
export default useFetchData;