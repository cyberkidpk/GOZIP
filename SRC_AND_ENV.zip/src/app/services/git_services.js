import axios from 'axios'
import { CONSTANTS } from '../../constants-and-configs'
import _ from 'lodash'
import {getFileFormat} from '../../utils'
export const getRepositories = async () => {

  let url =
    `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/2df205f6-df0d-4b64-a398-63fdccc58939/_apis/git/repositories?api-version=7.0`
  var response = {}
  try {
    response = await axios.get(url)
    response.message = 'Success'
  } catch {
    response.message = 'Error Received'
  }

  return response
}
export const getBranches = async (repoId) => {
  const url = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/_apis/git/repositories/${repoId}/refs?api-version=7.0`
  var response = { data: {}, message: '' }
  try {
    response = await axios.get(url)
    response.message = 'Success'
  } catch {
    response.message = 'Error Received'
  }
  console.log(response)
  return response
}

export const listItems = async () => {
  const repoId = localStorage.getItem('targetRepoId')
  const tarBranch = localStorage.getItem('targetBranch')
  const projectFolder = tarBranch.split('_')[0]
  console.log(repoId + ':::::::' + tarBranch)
  const url = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/_apis/git/repositories/${repoId}/items?scopePath=/src/${projectFolder}_emr&recursionLevel=Full&includeContentMetadata=true&versionDescriptor.versionType=branch&versionDescriptor.version=${tarBranch}&versionDescriptor.versionOptions=None&api-version=7.0`
  var response = { data: {}, message: '' }
  try {
    response = await axios.get(url)
    response.message = 'Success'
  } catch {
    response.message = 'Error Received'
  }
  console.log('LIST ITEMS', response)
  return response
}

export const GITSERVICES_RESOLVERS = {
  featureBranchResolver: async (market, branchName) => {
    try {
      var response = { data: {}, message: '' }
      let targetMarket = `${
        CONSTANTS.MARKETS[market].DEV_OPS_REF
      }`
      const repositories = await getRepositories()
      console.log(repositories)
      var {
        data: { value: repos },
        message: repomsg,
      } = repositories

      const targetRepo = _.find(repos, { name: targetMarket })
      let getBranchesForTarRepo = await getBranches(targetRepo.id)
      console.log('getBranchesForTarRepo', getBranchesForTarRepo)
      let {
        data: { value: branches },
        message: brmsg,
      } = getBranchesForTarRepo
      let targetBranch = _.find(branches, {
        name: `refs/heads/${branchName}`,
      })
      if (targetBranch) {
        localStorage.setItem('targetBranch', branchName)
        localStorage.setItem('targetRepoId', targetRepo.id)
      }

      return { data: { value: targetBranch }, message: 'Success' }
    } catch {
      return { data: {}, message: 'Unsuccess' }
    }
  },
  // folderResolver: async () => {
  //   var response = {}
  //   try {
  //     response = await listItems()
  //     const {
  //       data: { value: items },
  //     } = response
  //     var allFolders = _.filter(items, (obj) => {
  //       return obj.isFolder
  //     })
  //     const folderStrucureExist = allFolders.filter((o) => {
  //       const folderStringArr = o['path']?.split('/')
  //       // if (o['path'].indexOf('.readme') >= 0) {
  //       //   return false
  //       // }
  //       const filterSome = folderStringArr.filter((r) => {
  //         console.log(r)

  //         return (
  //           [
  //             'prod',
  //             'qa',
  //             'schema',
  //             'listfiles',
  //             'staticfiles',
  //             'config',
  //             'parameters',
  //             'properties',
  //             'autosysjobrun',
  //             'schemaremovaltracker',
  //             'schemachangetracker',
  //             'masterschema',
  //             'incomingschema',
  //           ].indexOf(r) >= 0
  //         )
  //       })
  //       return filterSome.length
  //     })
  //     console.log(folderStrucureExist)
  //     if (folderStrucureExist.length === 13) {
  //       response.message = 'success'
  //     } else {
  //       response.message = 'unsuccess'
  //     }
  //     console.log('folderStrucureExist.length', folderStrucureExist.length)
  //     return response
  //   } catch {
  //     response.message = 'Unsuccess'
  //   }

  //   return response
  // },
  folderResolver: async () => {
    var response = {}
    try {
      response = await listItems()
      const {
        status,
        data: { value: items },
      } = response

      let repoStructure = _.cloneDeep(CONSTANTS.REPO_TREE_STRUCTURE)
      items.forEach((o) => {
        const folderStringArr = o['path']?.split('/')
        folderStringArr.splice(0, 3) // remove src and rootFolder name
        let path = repoStructure[0];
         console.log('array',folderStringArr)
        folderStringArr.forEach((name, i, array) => {

            if(i === (folderStringArr.length - 1) && !o.isFolder){
              let fileIndex = _.findIndex(path.files, (o) =>  o.name === name)
              if(fileIndex == -1){
                path.files.push({
                  ...o,
                  type: 'file',
                  name: name,
                  hasPermission: array.indexOf(CONSTANTS.ENV.DEV) >=0 && array.indexOf('.readme') == -1 ? true : false,
                  permissible: array.indexOf(CONSTANTS.ENV.DEV) >=0 ? ['edit'] : null
                })
              }
            }else{
              let folderIndex = _.findIndex(path.files, (o) =>  o.name === name);
              if(folderIndex == -1){
               let fileFormat = getFileFormat(name)
                path.files.push({
                  ...o,
                  type: 'folder',
                  name: name,
                  files: [],
                  hasPermission: array.indexOf(CONSTANTS.ENV.DEV) >=0 && name !='schema'  ? true : false,
                  permissible: array.indexOf(CONSTANTS.ENV.DEV) >=0 ? ['add'] : null,
                  fileFormat
                })
              }
              folderIndex = _.findIndex(path.files, (o) =>  o.name === name);
              path = path['files'][folderIndex]
           //   console.log('path', path)
            }
        })
      })

      //   console.log("treeStructure",repoStructure)
      //       repoStructureconst folderStrucureExist = items.filter((o) => {
      //        const folderStringArr = o['path']?.split('/')
      //
      //        if (o['path'].indexOf('.readme') >= 0) {
      //          return false
      //        }
      //
      //        const filterSome = folderStringArr.filter((r) => {
      //         // console.log(r)
      //          return (
      //            [
      //              'prod',
      //              'qa',
      //              'schema',
      //              'listfiles',
      //              'staticfiles',
      //              'config',
      //              'parameters',
      //              'properties',
      //              'autosysjobrun',
      //              'schemaremovaltracker',
      //              'schemachangetracker',
      //              'masterschema',
      //              'incomingschema',
      //            ].indexOf(r) >= 0
      //          )
      //        })
      //        return filterSome.length
      //      })
      //console.log(folderStrucureExist)
      if (status === 200) {
        response.value = repoStructure
        response.message = 'success'
      } else {
        response.message = 'unsuccess'
      }
      //  console.log('folderStrucureExist.length', folderStrucureExist.length)
      return response
    } catch (e) {
      console.log(e)
      response.message = 'Unsuccess'
    }

    return response
  },
}


export const GITSERVICES = {
  GITSERVICES_RESOLVERS,
  getBranches,
  getRepositories,
}
