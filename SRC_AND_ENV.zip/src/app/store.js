import { configureStore } from '@reduxjs/toolkit'
import counterReducer from '../features/counter/counterSlice'
import prosPipesReducer from '../features/projectsAndPipelines/projectsAndPipelinesSlice'
import loginReducer from '../features/login/loginSlice'

export const store = configureStore({
  reducer: {
    counter: counterReducer,
    projectsAndPipelines: prosPipesReducer,
    loginInfo: loginReducer,
  },
})
