import React from 'react'

import { Box, Meter, Text, Tip, Button, Anchor, Spinner } from 'grommet'
import { CONSTANTS } from '../../constants-and-configs'
import axios from 'axios'

const amountFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 2,
})

const triggerPipeline = (projectId) => {
  console.log('CALL PRO ID', projectId)
  const token = '7imqmsyfz5uqjfh3bo7pnt4vj44kf3rspor6o6rfe2bz7qeccpna'
  //window.localStorage.getItem("access_token")

  let configHead = {}
  if (token) {
    axios.defaults.headers.common = {
      Authorization: 'Basic ' + btoa('' + ':' + token),
    }
  }
  const endpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/${projectId}/_apis/pipelines/1/runs?pipelineVersion=1&api-version=7.0`
   const repoParam = {
    resources: {
      repositories: {
        self: {
          refName: 'refs/heads/dev_branch',
        },
      },
    },
  }
  if (projectId) {
    axios.post(endpoint, repoParam).then((statusResp) => {
      alert('Triggered')
    })
  }
}

export const columns = [
  {
    property: 'name',
    header: <Text>Team</Text>,
  },
  {
    property: 'project',
    header: 'Projects',
  },
  {
    property: 'createdDate',
    header: 'Pipeline Created Date',
    render: (datum) =>
      datum.createdDate &&
      new Date(datum.createdDate).toLocaleDateString('en-US'),
    align: 'end',
  },
  {
    property: 'finishedDate',
    header: 'Pipeline Finished Date',
    render: (datum) =>
      datum.finishedDate &&
      new Date(datum.finishedDate).toLocaleDateString('en-US'),
    align: 'end',
  },
  {
    property: 'result',
    header: 'Approval and Result',
    render: ({ result, url, state, addparameters }) => {
      switch (result) {
        case 'failed':
          return (
            <Anchor
              type="button"
              size="small"
              title="Go to Pipeline"
              label="Canceled"
              primary
              color="red"
              href={url}
              target="_blank"
            />
          )
        case 'succeeded':
          return (
            <Anchor
              type="button"
              size="small"
              title="Request is approved, check detailed state"
              label={
                addparameters === 'no' && result === 'succeeded'
                  ? 'Initialized'
                  : result
              }
              primary
              color="green"
              href="/view-status-and-details"
            />
          )
        case 'canceled':
          return (
            <Anchor
              type="button"
              size="small"
              title="Go to Pipeline"
              label="Canceled"
              primary
              color="red"
              href={url}
              target="_blank"
            />
          )
        case 'unknown':
          return (
            <Anchor
              type="button"
              size="small"
              title="Queued or Unknown : Go to Pipeline"
              label="Queued or In Progress"
              primary
              color="orange"
              href={url}
              target="_blank"
            />
          )
        default:
          return state == 'inProgress' ? (
            <Box>
              <Spinner></Spinner>
              <Anchor
                type="button"
                size="small"
                title="Go to Pipeline"
                label="In Progress"
                primary
                color="orange"
                href={url}
              />
            </Box>
          ) : (
            <Anchor
              type="button"
              size="small"
              title="Go to Pipeline"
              label="Queued"
              primary
              color="orange"
              href={url}
            />
          )
      }
    },
  },
  {
    property: 'state',
    header: 'Pipeline state',
    render: ({ state, result }) => {
      switch (state) {
        case 'completed':
          return (
            <>
              {result == 'canceled' ? (
                <Box
                  pad={{ vertical: 'xsmall' }}
                  background="#fd1a1a"
                  style={{ padding: '10px' }}
                >
                  <Meter
                    values={[{ value: 10 }]}
                    primary
                    thickness="small"
                    size="small"
                  />
                </Box>
              ) : (
                <Box
                  pad={{ vertical: 'xsmall' }}
                  background="green"
                  style={{ padding: '10px' }}
                >
                  <Meter
                    values={[{ value: 100 }]}
                    primary
                    thickness="small"
                    size="small"
                  />
                </Box>
              )}
            </>
          )
        case 'inProgress':
          return (
            <Box pad={{ vertical: 'xsmall' }}>
              <Meter
                values={[{ value: 30 }]}
                color="green"
                thickness="small"
                size="small"
              />
            </Box>
          )

        case 'canceling':
          return (
            <Box pad={{ vertical: 'xsmall' }}>
              <Meter
                values={[{ value: 0 }]}
                color="red"
                thickness="small"
                size="small"
              />
            </Box>
          )
        default:
          return (
            <Box pad={{ vertical: 'xsmall' }}>
              <Meter
                values={[{ value: 0 }]}
                color="red"
                thickness="small"
                size="small"
              />
            </Box>
          )
      }
    },
  },
  {
    property: 'runpipeline',
    header: 'Trigger The Pipeline',
    render: ({ state, result, projectId, addparameters }) => {
      return (state === 'unknown' || state == 'completed') &&
        projectId &&
        addparameters === 'review' ? (
        <Button primary onClick={() => triggerPipeline(projectId)}>
          Trigger
        </Button>
      ) : (
        <Text primary size="small" color="red">
          {state === 'inProgress'
            ? 'Pipeline is in progress'
            : 'Config File is not found'}
        </Text>
      )
    },
  },
  {
    property: 'addparameters',
    header: 'Config File Status - Add or Review',
    render: (datum) => {
      return datum.state === 'unknown' ? (
        <Anchor
          type="button"
          size="small"
          label="Add Parameters"
          primary
          href="/sqoop"
        />
      ) : datum.state === 'completed' && datum.addparameters === 'no' ? (
        <Anchor
          type="button"
          size="small"
          color="blue"
          label="Add Config File"
          primary
          href="/sqoop"
        />
      ) : datum.state === 'inProgress' ? (
        <Text size="small" color="red">
          Pipeline is in progress
        </Text>
      ) : (
        <Anchor
          type="button"
          size="small"
          color="blue"
          label="File Exist- Review Config File"
          primary
          href="/sqoop"
        />
      )
    },
  },
]

export const groupColumns = [...columns]
const first = groupColumns[0]
groupColumns[0] = { ...groupColumns[1] }
groupColumns[1] = { ...first }
//groupColumns[0].footer = groupColumns[1].footer;
//delete groupColumns[0].footer;

export const projects = ['CDL2.0 Silver', 'CDL2.0 Gold']

export const data = []

for (let i = 0; i < 40; i += 1) {
  data.push({
    name: `Name ${i + 1}`,
    project: projects[i % projects.length],
    date: `2022-07-${(i % 30) + 1}`,
    percent: (i % 11) * 10,
    //addparameters: ((i + 1) * 17) % 1000,
  })
}

export const DATA = [
  {
    name: 'Alan',
    project: 'CDL2.0 Gold',
    createdDate: '',
    finishedDate: '',
    result: 'succeeded',
    state: 'completed',
    url: '',
    addparameters: 0,
  },
  {
    name: 'Bryan',
    project: 'CDL2.0 Silver',
    date: '2022-06-10',
    percent: 30,
    requeststate: 'Approved',
    addparameters: 1234,
  },
  {
    name: 'Chris',
    project: 'CDL2.0 Silver',
    date: '2022-06-09',
    percent: 40,
    requeststate: 'Approved',
    addparameters: 2345,
  },
  {
    name: 'Eric',
    project: 'CDL2.0 Gold',
    date: '2022-06-11',
    percent: 80,
    requeststate: 'Approved',
    addparameters: 3456,
  },
  {
    name: 'Doug',
    project: 'CDL2.0 Silver',
    date: '2022-06-10',
    percent: 60,
    requeststate: 'Approved',
    addparameters: 1234,
  },
  {
    name: 'Jet',
    project: 'CDL2.0 Gold',
    date: '2022-06-09',
    percent: 40,
    requeststate: 'Approved',
    addparameters: 3456,
  },
  {
    name: 'Michael',
    project: 'CDL2.0 Gold',
    date: '2022-06-11',
    percent: 50,
    requeststate: 'Approved',
    addparameters: 1234,
  },
  {
    name: 'Tracy',
    project: 'CDL2.0 Silver',
    date: '2022-06-10',
    percent: 10,
    requeststate: 'Approved',
    addparameters: 2345,
  },
]
