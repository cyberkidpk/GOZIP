import React from 'react'
import {
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
  Route,
  Navigate,
} from 'react-router-dom'

import { ProtectedRoute } from './app/ProtectedRoute'
import './index.css'
import { RouterComponent } from './app/router'
import { Grommet, grommet, Page, PageContent } from 'grommet'
import { Nav } from './app/Nav'
import App from './App'
import { AuthLayout } from './app/AuthLayout'
import { Home } from './features/home'
import { Login } from './features/login'
import Authenticate from './authenticate'
import {
  SqoopIngestion,
  SqoopIngestionSchemaBased,
  ReviewIngestion,
} from './features/categories'
import { ProjectsAndPipelines } from './features/projectsAndPipelines'
import { ViewStatusAndDetails } from './features/viewStatusAndDetails'
import { EntryPoint } from './features/categories/EntryPoint'
import { DevRequestForm } from './features/categories/DevRequest'
import { WorkflowIngestionComponent } from './features/ingestions/batch/WorkflowIngestionComponent'
import { OnboardingInit } from './features/ingestions/batch/OnboardingInit'
import { FilesGeneratorComponent } from './features/ingestions/batch/FilesGenerator'
import { WorkflowOutlet } from './features/ingestions/batch/WorkflowOutlet'

const customTheme = {
  global: {
    font: {
      family: 'Arial',
      size: '1.2rem',
    },
    colors: {
      blue: '#00C8FF',
      green: '#17EBA0',
      teal: '#82FFF2',
      purple: '#82FFF2',
      red: '#FC6161',
      orange: '#FFBC44',
      yellow: '#FFEB59',
    },
  },
  anchor: {
    color: '#B90351',
    active: {
      extend: `text-decoration:underline;`,
    },
  },
  button: {
    border: {
      radius: '10px',
      color: '#fff',
    },
    disabled: {
      color: 'orange',
      border: {
        color: 'orange',
      },
      extend: `border: 10px dashed red;`,
    },
    padding: {
      vertical: '12px',
      horizontal: '24px',
    },
    margin: {
      horizontal: '24px',
    },
    primary: {
      color: '#2196f3',
      active: {
        border: {
          color: 'red',
        },
        extend: `background: cadetblue;`,
      },
      extend: `background: #B90351; text-align:center; color:#efefef;`,
    },
  },
}

function Shell() {
  const routerApp1 = createBrowserRouter(
    createRoutesFromElements(
      <>
        <Route path="/" element={<Navigate to="/authenticate" />} />
        <Route path="/authenticate" element={<Authenticate />} />
        <Route path="/entry-point" element={<EntryPoint />} />
        <Route path="/entry-point-dev-request" element={<DevRequestForm />} />
        <Route path="/login" element={<Login />} />
        <Route element={<AuthLayout />}>
          <Route
            path="/projects-and-pipelines"
            element={<ProjectsAndPipelines />}
          />
          <Route path="/workflow-json" element={<WorkflowOutlet />}>
            <Route index element={<OnboardingInit />} />
            <Route path="workflow-step1" element={<OnboardingInit />} />
            <Route
              path="workflow-step2"
              element={<FilesGeneratorComponent />}
            />
            <Route
              path="workflow-step3"
              element={<WorkflowIngestionComponent />}
            />
          </Route>
          <Route path="/sqoop" element={<SqoopIngestionSchemaBased />} />
          <Route path="/review-ingestion" element={<ReviewIngestion />} />
          <Route
            path="/view-status-and-details"
            element={<ViewStatusAndDetails />}
          />
        </Route>
        <Route path="*" element={<Navigate to="/" />} />
      </>,
    ),
  )
  return (
    <Grommet theme={customTheme}>
      <div className="app-container">
        <Nav />
        <Page
          kind="full"
          style={{ background: 'transparent', padding: '24px' }}
        >
          <PageContent style={{ background: 'transparent', padding: 0 }}>
            <RouterProvider router={routerApp1} />
          </PageContent>
        </Page>
      </div>
    </Grommet>
    //    <Grommet theme={customTheme}>
    //         <div className="app-container">
    //                <Nav />
    //                <Page kind="full"  style={{background:"transparent"}}>
    //                  <PageContent style={{background:"transparent", padding:0}}>
    //                     <RouterProvider router={routerApp1} />
    //                 </PageContent>
    //                </Page>
    //            </div>
    //    </Grommet>
  )
}
export default Shell
