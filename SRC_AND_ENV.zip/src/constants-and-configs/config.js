import { CONSTANTS } from './constants'

const APP_CONFIG = {
  API_GATEWAY: {
    BASE_URL: 'http://192.168.0.132:4000',
  },
  DEVOPS_ORG: 'abbvie-devops-lab-test',
  DYNAMIC_S3_REF_HUNT: (
    market,
    project_name,
    env,
    config_resolve_type,
    ingestion_type,
  ) => {
    //keep ingestion_type 'batch' or 'sqoop for framework autosys ingestion
    var resolvePath = ''
    if (ingestion_type) {
      resolvePath = `${CONSTANTS.CDL_S3.BASE_URL[env]}/${ingestion_type}/src/${
        CONSTANTS.CDL_S3.INGESTION_TYPE[ingestion_type.toUpperCase()]
      }/autosys/`
    } else {
      resolvePath = `${CONSTANTS.CDL_S3.BASE_URL[env]}/${CONSTANTS.MARKETS[market]}/src/${project_name}/configuration/${config_resolve_type}/`
    }
  },
}
//"s3://s3-abb-us-e1-cdl-d-devops/code_repository/comm/framework/src/batch_ingestion/autosys/Autosys_S3Archival.sh",
//"s3://s3-abb-us-e1-cdl-d-devops/code_repository/comm/market_access/src/mhcdm/configuration/autosysjobrun/acc_outlet_move_script.properties"
export { APP_CONFIG }
//"market_access/src/mhcdm/configuration/config/env_config_mhcd_rltn_spc_phrm_acct_outlet_tbl.json",
//"market_access/src/mhcdm/configuration/properties/mhcd_tbl.json",
//market_access/src/mhcdm/configuration/autosysjobrun/
