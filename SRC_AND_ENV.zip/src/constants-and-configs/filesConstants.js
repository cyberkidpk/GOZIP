import config_temp_data from '../assets/data/dev/config/batch_ingestion_config.json'
import autosysjobrun_temp_data from '../assets/data/dev/autosysjobrun/batch_ingestion_autosysjobrun_config.json'
import properties_temp_data from '../assets/data/dev/properties/batch_ingestion_properties_config.json'
import schema_temp_data from '../assets/data/dev/schema/index.json'
import workflow_tem_data from '../assets/data/batch-workflow-template.json'
export const FILE_CONSTANT = {
  config: {
    data: config_temp_data,
  },
  properties: {
    data: properties_temp_data,
  },
  autosysjobrun: {
    data: autosysjobrun_temp_data,
  },
  schema: {
    data: schema_temp_data,
  },
  dev: {
    data: workflow_tem_data,
  },
  validator_keywords: [
    '{project-name}',
    '{market}',
    '{env}',
    '{db_market_term}',
  ],
}
