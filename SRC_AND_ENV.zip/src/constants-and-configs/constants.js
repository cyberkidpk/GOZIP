const CONSTANTS = {
  PROJECT_NAME: 'abbvie_emr',
  ENV: {
    DEV: 'dev',
    QA: 'qa',
    PROD: 'prod',
  },
  ENTITY_NAME: 'CommercialDataLake',
  PROJECTS_RESERVE_KEYWORDS: {
    DATA_INGESTION_JSON: [
      'dou',
      'dou-market',
      'dou-project-name',
      'dou-project-s3-repo-name',
    ],
  },

  MARKETS: {
    ["market-access"]: {
      KNOWN_NAME: 'market-access',
      S3_REF: 'market_access',
      DEV_OPS_REF: 'CommercialDatalake-market-access',
      DB: {
        db_market_term: 'ma360',
      },
    },
    ["marketing"]: {
      KNOWN_NAME: 'marketing',
      S3_REF: 'marketing',
      DEV_OPS_REF: 'CommercialDatalake-marketing',
      DB: {
        db_market_term: 'mktg',
      },
    },
    ["syndicated"]: {
      KNOWN_NAME: 'syndicated',
      S3_REF: 'syndicated',
      DEV_OPS_REF: 'CommercialDatalake-syndicated',
      DB: {
        db_market_term: 'syndi',
      },
    },
    ["operations"]: {
      KNOWN_NAME: 'operations',
      S3_REF: 'operations',
      DEV_OPS_REF: 'CommercialDatalake-operations',
      DB: {
        db_market_term: 'OPS',
      },
    },
    ["hcp360"]: {
      KNOWN_NAME: 'hcp360',
      S3_REF: 'hcp360',
      DEV_OPS_REF: 'CommercialDatalake-hcp360',
      DB: {
        db_market_term: 'hcp360',
      },
    },
  },
  APIS: {
    DEV_OPS_BASE_URL: `https://dev.azure.com/${process.env.REACT_APP_CDL_DEVOPS_ORG}`,
    GET_SUFFIX: {
      PROJECTS: '/_apis/projects?api-version=7.0',
      PIPELINES: '/_apis/pipelines?api-version=7.0',
      TEAMS: '/teams?api-version=7.0',
    },
  },
  PIPELINES: {
    BATCH_INGESTION: {
      JOB: 'spark',
      INGESTION_TYPE: 'batch',
      STEPS: {
        STEPS_COUNT_PER_JOB: 4,
        FIRST_DEFAULT: '_acc_outlet',
        STEPS_ORDER_NAME_FIRST_ARG: [
          { ftp_to_landing: ['vendor_s3_to_inbound_s3_move.sh'] },
          { validation: ['Autosys_Validation.sh'] },
          { ingestion: ['Autosys_Ingestion.sh'] },
          { s3_archival: ['Autosys_S3Archival.sh'] },
        ],
      },
    },
  },
  CDL_S3: {
    BASE_URL: {
      dev: 's3://s3-abb-us-e1-cdl-d-devops/code_repository/comm',
      qa: 's3://s3-abb-us-e1-cdl-q-devops/code_repository/comm',
      prod: 's3://s3-abb-us-e1-cdl-p-devops/code_repository/comm',
    },
    INGESTION_TYPE: {
      BATCH: 'batch_ingestion',
      SQOOP: 'sqoop_ingestion',
    },
    FRAMEWORK: {
      BATCH_AUTOSYS: {
        dev:
          's3://s3-abb-us-e1-cdl-d-devops/code_repository/comm/framework/src/batch_ingestion/autosys/',
        qa:
          's3://s3-abb-us-e1-cdl-q-devops/code_repository/comm/framework/src/batch_ingestion/autosys/',
        prod:
          's3://s3-abb-us-e1-cdl-p-devops/code_repository/comm/framework/src/batch_ingestion/autosys/',
      },
    },
    LIB: {
      Jar:
        's3://us-east-1.elasticmapreduce/libs/script-runner/script-runner.jar',
    },
  },
  REPO_TREE_STRUCTURE: [
    {
      type: 'folder',
      name: 'abbvie_emr',
      hasPermission: false,
      files: [
        {
          type: 'folder',
          name: 'configuration',
          hasPermission: false,
          files: [
            {
              type: 'folder',
              name: 'dev',
              hasPermission: true,
              permissible:['add'],
              fileFormat:{
                mustHave:'abbvie_emr',
                endWith:'_workflow',
                ext:'json',
                format:'()_project-name_workflow.json'
              },
              files: [],
            },
              {
              type: 'folder',
              name: 'qa',
              hasPermission: false,
              files: [],
            },
            {
              type: 'folder',
              name: 'prod',
              hasPermission: false,
              files: [],
            }]
           }],
        },
],
}
//  REPO_TREE_STRUCTURE: [
//    {
//      type: 'folder',
//      name: 'abbvie_emr',
//      hasPermission: false,
//      files: [
//        {
//          type: 'folder',
//          name: 'configuration',
//          hasPermission: false,
//          files: [
//            {
//              type: 'folder',
//              name: 'dev',
//              hasPermission: true,
//              permissible:['add'],
//              fileFormat:{
//                mustHave:'abbvie_emr',
//                endWith:'_workflow',
//                ext:'json',
//                format:'()_project-name_workflow.json'
//              },
//              files: [
//                {
//                  type: 'folder',
//                  name: 'autosysjobrun',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [],
//                  fileFormat:{
//                   mustHave:'abbvie_emr',
//                   endWith:'_move_script',
//                   ext:'properties',
//                   format:'()_project-name_()_move_script.properties'}
//                },
//                {
//                  type: 'folder',
//                  name: 'config',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [],
//                  fileFormat:{
//                    startWith:'env_config_',
//                    mustHave:'abbvie_emr',
//                    endWith:'_tbl',
//                    ext:'json',
//                    format:'env_config_()_project-name_tbl.json'}
//                },
//                {
//                  type: 'folder',
//                  name: 'parameters',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'properties',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [],
//                  fileFormat:{
//                  mustHave:'abbvie_emr',
//                  endWith:'_tbl',
//                  ext:'json',
//                  format:'()_project-name_tbl.json'}
//                },
//                {
//                  type: 'folder',
//                  name: 'staticfiles',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'listfiles',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'schema',
//                  hasPermission: true,
//                  permissible:['add'],
//                  files: [
//                    {
//                      type: 'folder',
//                      name: 'incomingschema',
//                      hasPermission: true,
//                      permissible:['add'],
//                      files: [],
//                      fileFormat:{
//                       mustHave:'abbvie_emr',
//                       endWith:'_tbl_incomingschema',
//                       ext:'txt',
//                       format:'()_project-name_tbl_incomingschema.txt'
//                    }
//                    },
//                    {
//                      type: 'folder',
//                      name: 'masterschema',
//                      hasPermission: true,
//                      permissible:['add'],
//                      files: [],
//                      fileFormat:{
//                       mustHave:'abbvie_emr',
//                       endWith:'_tbl_masterschema',
//                       ext:'txt',
//                       format:'()_project-name_tbl_masterschema.txt'
//                    }
//                    },
//                    {
//                      type: 'folder',
//                      name: 'schemachangetracker',
//                      hasPermission: true,
//                      permissible:['add'],
//                      files: [],
//                      fileFormat:{
//                       mustHave:'abbvie_emr',
//                       endWith:'_tbl_schemachangetracker',
//                       ext:'txt',
//                       format:'()_project-name_tbl_schemachangetracker.txt'
//                    }
//                    },
//                    {
//                      type: 'folder',
//                      name: 'schemaremovaltracker',
//                      hasPermission: true,
//                      permissible:['add'],
//                      files: [],
//                      fileFormat:{
//                       mustHave:'abbvie_emr',
//                       endWith:'_tbl_schemaremovaltracker',
//                       ext:'txt',
//                       format:'()_project-name_tbl_schemaremovaltracker.txt'
//                    }
//                    },
//                  ],
//                },
//              ],
//            },
//              {
//              type: 'folder',
//              name: 'qa',
//              hasPermission: false,
//              files: [
//                {
//                  type: 'folder',
//                  name: 'autosysjobrun',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'config',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'parameters',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'properties',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'staticfiles',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'listfiles',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'schema',
//                  hasPermission: false,
//                  files: [
//                    {
//                      type: 'folder',
//                      name: 'incomingschema',
//                      hasPermission: false,
//                      files: [], // type files
//                    },
//                    {
//                      type: 'folder',
//                      name: 'masterschema',
//                      hasPermission: false,
//                      files: [],
//                    },
//                    {
//                      type: 'folder',
//                      name: 'schemachangetracker',
//                      hasPermission: false,
//                      files: [],
//                    },
//                    {
//                      type: 'folder',
//                      name: 'schemaremovaltracker',
//                      hasPermission: false,
//                      files: [],
//                    },
//                  ],
//                }
//              ],
//            },
//              {
//              type: 'folder',
//              name: 'prod',
//              hasPermission: false,
//              files: [
//                {
//                  type: 'folder',
//                  name: 'autosysjobrun',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'config',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'parameters',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'properties',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'staticfiles',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'listfiles',
//                  hasPermission: false,
//                  files: [],
//                },
//                {
//                  type: 'folder',
//                  name: 'schema',
//                  hasPermission: false,
//                  files: [
//                    {
//                      type: 'folder',
//                      name: 'incomingschema',
//                      hasPermission: false,
//                      files: [],
//                    },
//                    {
//                      type: 'folder',
//                      name: 'masterschema',
//                      hasPermission: false,
//                      files: [],
//                    },
//                    {
//                      type: 'folder',
//                      name: 'schemachangetracker',
//                      hasPermission: false,
//                      files: [],
//                    },
//                    {
//                      type: 'folder',
//                      name: 'schemaremovaltracker',
//                      hasPermission: false,
//                      files: [],
//                    },
//                  ],
//                },
//              ],
//            },
//            {
//              type: 'file',
//              name: 'cdl-market-access-build-abbvie-emr-configuration.yml',
//              hasPermission: false,
//            },
//          ],
//        },
//      ],
//    },
//  ],
//}

export { CONSTANTS }
