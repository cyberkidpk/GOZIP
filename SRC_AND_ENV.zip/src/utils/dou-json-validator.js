import { CONSTANTS } from '../constants-and-configs'

export const DOU_JSON_VALIDATOR = {
  findReserveKeywords: (json) => {
    const stringifier = JSON.stringify(json)
    //let rev_Key_count = {}

    var countPro = (stringifier.match(/dou/g) || []).length

    return countPro
  },
}
