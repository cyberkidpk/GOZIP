import { DOU_JSON_VALIDATOR } from './dou-json-validator'

const generateRandomValue = () => {
  let crypto = window.crypto || window.msCrypto
  let D = new Uint32Array(2)
  crypto.getRandomValues(D)
  return D[0].toString(36)
}
const getAccessIdTokenFromTheUrl = (urlString) => {
  // var finalString = urlString.replace(/#/g,"?")
  // var url = new URL(urlString);
  var hash = window.location.hash.substr(1)

  var result = hash.split('&').reduce(function (res, item) {
    var parts = item.split('=')
    res[parts[0]] = parts[1]
    return res
  }, {})
  // var access_token = new URLSearchParams(url.search).get('access_token');
  // var id_token = new URLSearchParams(url.search).get('id_token');
  const { access_token, id_token } = result
  return {
    access_token,
    id_token,
  }
}
const containsAny = (str, substrings) => {
  for (var i = 0; i != substrings.length; i++) {
    var substring = substrings[i]
    if (str.indexOf(substring) != -1) {
      return substring
    }
  }
  return null
}

const winConfirm = (msg) =>{
return window.confirm(`${msg}`)
}

const generateDataFromTemplate = (data, mapObj) =>{
    let regexPattern = Object.keys(mapObj).join('|') ;
    let originalData = data ? JSON.stringify(data) : null;
    originalData = originalData?.replace(new RegExp(`${regexPattern}`, 'gi'), (matched)=> mapObj[matched])
    return originalData ? JSON.parse(originalData) : null
}

const getFileFormat = (name) =>{
let fileFormat;
switch (name) {
    case 'autosysjobrun':
        fileFormat= {
            mustHave: 'abbvie_emr',
                endWith: '_move_script',
                ext: 'properties',
                format: 'YOUR-STRING_{project-name}_YOUR-STRING_move_script.properties , _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;
    case 'config':
        fileFormat= {
            startWith: 'env_config_',
                mustHave: 'abbvie_emr',
                endWith: '_tbl',
                ext: 'json',
                format: 'env_config_YOUR-STRING_{project-name}_tbl.json, _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;

    case 'properties':
        fileFormat = {
            mustHave: 'abbvie_emr',
                endWith: '_tbl',
                ext: 'json',
                format: 'YOUR-STRING_{project-name}_tbl.json _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;
    case 'incomingschema':
        fileFormat = {
            mustHave: 'abbvie_emr',
                endWith: '_tbl_incomingschema',
                ext: 'txt',
                format: 'YOUR-STRING_{project-name}_tbl_incomingschema.txt,  _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;
    case 'masterschema':
        fileFormat= {
            mustHave: 'abbvie_emr',
                endWith: '_tbl_masterschema',
                ext: 'txt',
                format: 'YOUR-STRING_{project-name}_tbl_masterschema.txt _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;
    case 'schemachangetracker':
        fileFormat = {
            mustHave: 'abbvie_emr',
                endWith: '_tbl_schemachangetracker',
                ext: 'txt',
                format: 'YOUR-STRING_{project-name}_tbl_schemachangetracker.txt, _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;
    case 'schemaremovaltracker':
        fileFormat = {
            mustHave: 'abbvie_emr',
                endWith: '_tbl_schemaremovaltracker',
                ext: 'txt',
                format: 'YOUR-STRING_{project-name}_tbl_schemaremovaltracker.txt, _{project-name}_ example could be current project is mhcdm then _mhcdm_emr_'
        }
        break;
    default:
      fileFormat= null
        // code block
}
return fileFormat
}
export {
  generateRandomValue,
  getAccessIdTokenFromTheUrl,
  DOU_JSON_VALIDATOR,
  containsAny,
  winConfirm,
  generateDataFromTemplate,
  getFileFormat
}
