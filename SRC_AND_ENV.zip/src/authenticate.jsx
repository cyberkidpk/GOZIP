import React, { useEffect, useState } from 'react'
// import authClient from './sdk/api'

import _ from 'lodash'
import config from './config'
import useFetchData from './app/hooks/curd'
import { generateRandomValue } from './utils'
import { Button, Layer, Card, CardHeader, CardBody, Text, Box } from 'grommet'
import { useNavigate } from 'react-router-dom'

const Authenticate = () => {
  const [show, setShow] = useState(true)
  const navigate = useNavigate()
  const authParams = {
    client_id: config.clientId,
    client_secret: config.clientSecret,
    redirect_uri: config.redirectURI,
    response_type: 'Implicit',
    scope: config.scope,
  }
  //const { data, loading, apiError } = useFetchData('post', 'https://federationdev.abbvie.com/as/token.oauth2', authParams);
  let stateparam = generateRandomValue()
  let nonceparam = generateRandomValue()
  let authUrl =
    `https://federationdev.abbvie.com/as/authorization.oauth2?` +
    `client_id=${config.clientId}&` +
    `redirect_uri=${config.redirectUri}&` +
    `response_type=${
      config.responseType ? config.responseType : 'token id_token'
    }` +
    (config.prompt ? `&prompt=${config.prompt}` : '') +
    (config.scope ? `&scope=${config.scope}` : '') +
    (config.maxAge ? `&max_age=${config.maxAge}` : '') +
    (stateparam ? `&state=${stateparam}` : '') +
    (nonceparam ? `&nonce=${nonceparam}` : '') +
    (config.acrValues ? `&acr_values=${config.acrValues}` : '')

  useEffect(() => {
    //console.log(data)
  }, [])
  return (
    <>
      <Layer
        onEsc={() => setShow(false)}
        onClickOutside={() => setShow(false)}
        background="dark"
        id="login-layer-auth"
      >
        <Card
          height="medium"
          width="medium"
          pad="medium"
          background="light-1"
          style={{ borderRadius: '20px', background: '#999' }}
        >
          <CardHeader pad="medium">
            {/* <Image src={Logo} width="200"/>*/}
            <svg
              xmlns="http://www.w3.org/2000/svg"
              version="1.1"
              x="0px"
              y="0px"
              viewBox="0 0 150 40"
              role="img"
            >
              <g>
                <path
                  class="st0"
                  d="M136.7,30c0-1.3-0.8-1.8-2-1.8c-0.7,0-9.2,0-9.2,0c-4.5,0-5.6-2.7-5.8-4.4c0,0,9.5,0,12.5,0c3.8,0,5-2.8,5-4.6   c0-1.9-1.2-4.6-5-4.6c-3.4,0-6.9,0-6.9,0c-6.5,0-8.6,4.4-8.6,8c0,3.9,2.4,8,8.6,8h11.4C136.7,30.7,136.7,30.1,136.7,30z M125.5,17   c1,0,4.6,0,6,0c2.2,0,2.7,1.3,2.7,2.2c0,0.8-0.5,2.2-2.7,2.2c-1.5,0-12,0-12,0C119.7,20,121,17,125.5,17z M98.8,29.7   c-0.7,0.9-1,1.3-1.7,1.3c-0.9,0-1.1-0.4-1.7-1.3c-1.4-2-9.8-15-9.8-15s0.6,0,1.2,0c2,0,2.6,0.9,3.2,1.9c0.5,0.8,7.3,11.2,7.3,11.2   s6.4-9.9,7.3-11.3c0.6-0.9,1.4-1.8,3.3-1.8c0.4,0,0.9,0,0.9,0S100,28.1,98.8,29.7z M35.7,30.7c-1.5,0-2.1-0.6-2.3-1.8L33,27.2   c-0.4,0.7-2.4,3.5-6.8,3.5c0,0-2.2,0-4.5,0c-6.8,0-8.7-4.6-8.7-8c0-3.8,2.3-8,8.7-8c1.3,0,2.7,0,4.8,0c4.9,0,7.6,2.8,8.2,6.3   c0.5,2.9,1.8,9.7,1.8,9.7S36.2,30.7,35.7,30.7z M25.8,17.2c-1.6,0-2,0-3.8,0c-4.6,0-6.1,2.9-6.1,5.5c0,2.6,1.5,5.5,6.1,5.5   c1.9,0,2.5,0,3.8,0c4.8,0,6.1-3,6.1-5.5C31.9,20.5,30.7,17.2,25.8,17.2z M111.9,12.1c0.7,0,1.4-0.4,1.4-1.3c0-0.2,0-0.4,0-0.5   c0-0.8-0.7-1.3-1.4-1.3c-0.7,0-1.4,0.4-1.4,1.3c0,0.1,0,0.3,0,0.5C110.5,11.7,111.2,12.1,111.9,12.1z M110.6,14.7c0,0,0.4,0,0.6,0   c1.3,0,2.1,0.7,2.1,2.1c0,0.2,0,13.9,0,13.9s-0.3,0-0.6,0c-1.3,0-2.1-0.8-2.1-2.2C110.6,28.4,110.6,14.7,110.6,14.7z M41,17   c0.6-0.6,2.4-2.3,5.9-2.3c0,0,2.2,0,4.5,0c6.8,0,8.8,4.6,8.8,8c0,3.8-2.4,8-8.8,8c-1.3,0-2.7,0-4.8,0c-4.9,0-8.4-3.1-8.4-8   c0-1.6,0-13.4,0-13.4s0.5,0,0.8,0c1.4,0,2,0.7,2,1.9C41,11.4,41,17,41,17z M47.3,28.2c1.6,0,2,0,3.8,0c4.5,0,6.1-2.9,6.1-5.5   c0-2.6-1.5-5.5-6.1-5.5c-1.9,0-2.5,0-3.8,0c-4.8,0-6.1,3-6.1,5.5C41.1,24.9,42.4,28.2,47.3,28.2z M66.1,17c0.6-0.6,2.4-2.3,5.9-2.3   c0,0,2.2,0,4.5,0c6.8,0,8.7,4.6,8.7,8c0,3.8-2.3,8-8.7,8c-1.3,0-2.7,0-4.8,0c-4.9,0-8.4-3.1-8.4-8c0-1.6,0-13.4,0-13.4s0.5,0,0.8,0   c1.4,0,2,0.7,2,1.9C66.1,11.4,66.1,17,66.1,17z M72.4,28.2c1.6,0,2,0,3.8,0c4.6,0,6.1-2.9,6.1-5.5c0-2.6-1.5-5.5-6.1-5.5   c-1.9,0-2.4,0-3.8,0c-4.8,0-6.1,3-6.1,5.5C66.2,24.9,67.5,28.2,72.4,28.2z"
                ></path>
              </g>
            </svg>
          </CardHeader>
          <CardBody>
            <Box size="medium" align="center" justify="center">
              <Text
                size="large"
                align="center"
                style={{
                  fontSize: '14px',
                  marginTop: '12px',
                  textAlign: 'center',
                }}
              >
                Part of Data Ingestion Utility, AbbVie Team?
              </Text>
              <Button
                background="primary"
                primary
                size="large"
                style={{
                  fontSize: '20px',
                  padding: '8px',
                  borderRadius: '12px',
                  marginTop: '32px',
                }}
                onClick={() => {
                  navigate('/login')
                }}
              >
                Authenticate
              </Button>
            </Box>
          </CardBody>
        </Card>
      </Layer>
    </>
  )
}

export default Authenticate
