import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Image,
  Text,
  TextInput,
  // Form,
  FormField,
  Button,
  Spinner,
  RadioButtonGroup,
} from 'grommet'

import validator from '@rjsf/validator-ajv8'
import Form from '@rjsf/core'

import '../../../assets/css/_sqoop.scss'
import axios from 'axios'
import { useSelector } from 'react-redux'
import { projectsValue } from '../../projectsAndPipelines'
import {CONSTANTS} from '../../../constants-and-configs/'
const FormFieldSqoop = [
  'SRC_DB',
  'SRC_TABLE',
  'IS_TARGET_TABLE',
  'STAGE_HIVE_DB',
  'STAGE_HIVE_TABLE',
  'TARGET_HIVE_DB',
  'TARGET_HIVE_TABLE',
  'AUDIT_DB',
  'AUDIT_TABLE',
  'DATA_PROV_NAME',
  'DATA_SET',
  'PROCESS_DESC',
  'SOURCE_PULL_REQUIRE_TARGET_VALUE_IND',
  'INCREMENT_SOURCE_COLUMN_NAME',
  'INCREMENT_HIVE_COLUMN_NAME',
  'TARGET_QRY_FOR_INCREMENT_VALUE',
  'INCREMENT_SOURCE_TARGET_COMPARATOR',
  'SOURCE_QUERY_OR_TABLE_INDICATOR',
  'QUERY_TO_PULL_FROM_SOURCE',
  'PRE_SQL_FOR_TARGET',
  'WHERE_CONDITION',
  'MAPHIVECOL',
  'TGTFILEPATH',
  'BKPFILEPATH',
  'ConnectionURL',
  '#SecretKeyPath',
  'UserName',
  'PasswordFile',
  'Driver',
  'SplitColumn',
  'TableMapperNum',
  'QueryMapperNum',
  'InputByMethod',
  'IsSourcePartitioned',
  'CHARSET',
]
const schema = {
  title: 'PRM FILE PARAMETERS',
  description: 'Review or Add',
  type: 'object',
  required: FormFieldSqoop,
  properties: {},
}

const uiSchema = {
  system_src: {
    'ui:widget': 'select',
  }, // could also be "select"
  'ui:order': FormFieldSqoop,
}

uiSchema['ui:order'].map((item) => {
  schema.properties[item] = {}
  schema.properties[item].type = 'string'
})

console.log('scheme', schema)
//   const formData = {
//     booleanWithCustomLabels:{

//     }

//   }

export { SqoopIngestionSchemaBased }

function SqoopIngestionSchemaBased() {
  const [value, setValue] = useState({ name: 'a', email: 'b' })
  const [valueR, setValueR] = useState('Market Access 360')
  const projectsValuePP = useSelector(projectsValue)
  const reviewObj = JSON.parse(window.localStorage.getItem('review'))
  const { project_id, project_name, review } = reviewObj

  const [formDataInput, setFormDataInput] = useState({
    sqoop_file_name: `${project_name}_sqoop.prm`,
  })

  const message =
    value.name && value.email && value.name[0] !== value.email[0]
      ? 'Mismatched first character'
      : undefined

  const navigate = useNavigate()

  const readfile = async () => {
    try {
      const response = await axios.get('http://10.74.40.62:4000/read-file', {
        project_id,
        project_name,
      })
      setFormDataInput({ ...formDataInput, ...response.data })
    } catch (error) {
      alert(
        'Not able to fetch the file to populate the form, click OK to RETRY!!!',
      )

      const fileUrl =
        `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/2df205f6-df0d-4b64-a398-63fdccc58939/_apis/sourceProviders/TfsGit/filecontents?repository=data_onboarding_utility_repo&commitOrBranch=dev_branch&path=data_onboarding_utility_project_sqoop.prm&api-version=7.0`
      const fileContentResponse = axios.default.get(fileUrl).then(
        (fileContent) => {
          console.log(fileContent.data)
          axios.default
            .post('http://10.74.40.62:4000/retry-read-file', {
              fileDataString: fileContent.data,
            })
            .then(
              (fileJSON) => {
                console.log(fileJSON)
                const { data: fileDataString } = fileJSON
                //console.log(typeof fileDataString)
                // const fileDataObj = JSON.parse(fileDataString)
                setFormDataInput({ ...formDataInput, ...fileDataString })
              },
              (error) => {
                alert('Error Again- Try after some time')
              },
            )
        },
        () => {
          return { message: 'Error fetching file' }
        },
      )
      setFormDataInput({ ...formDataInput })
    }
  }
  useEffect(() => {
    if (review === null || review === undefined) {
      window.location.href = '/projects-and-pipelines'
      return false
    }
    if (review) {
      readfile()
    } else {
      readfile()
    }
  }, [])
  return (
    <Box
      style={{ background: '#fff' }}
      align="center"
      justify="center"
      className="sqoop-form"
    >
      <Box gap="small" width="1300px" className={`${review}-review`}>
        {
          // navigate("/review-ingestion")
        }
        <Form
          schema={schema}
          uiSchema={uiSchema}
          formData={formDataInput}
          validator={validator}
          onSubmit={(value) => {
            const addi_info = { project_id, project_name }
            if (review) {
              addi_info.ctype = 'edit'
              if (
                window.confirm(
                  'Are you really sure to Overwrite the current .prm file?\n',
                )
              ) {
              } else {
                return
              }
            }
            axios
              .post('http://10.74.40.62:4000/upload-file', {
                ...value.formData,
                ...addi_info,
              })
              .then(
                (resp) => {
                  alert('.PRM FILE IS OVERWRITTEN!!')
                },
                (error) => {
                  console.log('ERRRRRRRRRRRRRRRRROOOOOOR')
                  console.log(error)
                },
              )
          }}
        />
        {review ? (
          <Box style={{ justifyContent: 'flex-start' }}>
            <Text
              size="large"
              primary
              style={{
                display: 'block',
                backgroundColor: 'brown',
                color: '#efefef',
                borderRadius: '12px',
                border: '4px solid #efefef',
                padding: '8px',
                width: '200px',
                marginTop: '-110px',
              }}
            >
              Config File Already Exist- Would you like to overwrite
            </Text>
            <Text size="small" style={{ fontSize: '10px', color: 'red' }}>
              ***Repo file remain the same if there are no changes
            </Text>
          </Box>
        ) : (
          ''
        )}
      </Box>
    </Box>
  )
}
