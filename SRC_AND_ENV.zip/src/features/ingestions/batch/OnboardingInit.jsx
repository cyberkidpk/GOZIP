import axios from 'axios'
import {
  Box,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Spinner,
  Text,
} from 'grommet'
import { set } from 'lodash'
import React, { useEffect } from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { GITSERVICES } from '../../../app/services/git_services'
import { StatusCard } from '../../../app/components/StatusCard'
var onboardingStat = { step:1, isFolderStructureExist:'InProgress', color:'orange', title:["Project Folder", "Project Configuration folder","Project YAML file", "DEV, QA and PROD reference"] }
 var intervalSet = 0 ;
export const OnboardingInit = () => {

  const [isFolderStructureExist, setIsFolderStructureExist] = useState(false)
  var [onboardingStatus, setOnboardingStatus]= useState(onboardingStat)
  const navigate = useNavigate()

  useEffect(() => {

         intervalSet = setInterval(()=>{
         if(onboardingStatus.step >=3){
         clearInterval(intervalSet)
         }
         onboardingStatus.isFolderStructureExist = true;
         onboardingStatus.color = 'green';
         onboardingStatus.title = onboardingStatus.title[onboardingStatus.step-1]
         onboardingStatus.step++;

         setOnboardingStatus(onboardingStatus)
         setIsFolderStructureExist('InProgress')
         }, 2000)
    return () => {
      window.localStorage.setItem('tree', null)
    }
  }, [])
  useEffect(() => {setIsFolderStructureExist(true)},[onboardingStatus.step])
  return (
    <>
      <Box
        width="100%"
        height="30px"
        background={'#999'}
        align="center"
        direction="column"
        margin={'auto'}
        style={{ fontSize: '1.5rem', color: 'white' }}
      >
        <Text align="center" width="100%">
          Azure Repos Folder Blueprint Verifier
        </Text>
      </Box>
      <Box
        width="800px"
        height="400px"
        background={'#efefef'}
        align="center"
        direction="row"
        margin={'auto'}
        style={{ fontSize: '1rem', color: 'orange' }}
      >
       <StatusCard onboardingStatus={onboardingStatus}/>
        <Box justify="center" align="center">
          {isFolderStructureExist !== 'failed' ? (
            <Button
              width="100px"
              height="30px"
              style={{ padding: '10px' }}
              margin="medium"
              primary
              onClick={() => {
                navigate('workflow-step2')
              }}
            >
              Proceed Futher
            </Button>
          ) : isFolderStructureExist == 'failed' ? (
            <Text size="large" color="red">
              {' '}
              Correct the folder structure!!!{' '}
            </Text>
          ) : (
            <Spinner color={'green'} size="large"></Spinner>
          )}
        </Box>
      </Box>
    </>
  )
}
