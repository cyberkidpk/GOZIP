import {
  Box,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Spinner,
  Text,
  Layer,
} from 'grommet'

import React, { useEffect, useState, useLayoutEffect } from 'react'

import '../../../app/components/directory-tree/styles.css'

import Tree from '../../../app/components/directory-tree/Tree/Tree'
import WorkflowJSON from '../../../assets/data/batch-workflow-template.json'
import { useNavigate } from 'react-router-dom'
import { JSONFormInputComponent } from './JSONFormInput'
import _, { find } from 'lodash'
import { FILE_CONSTANT } from '../../../constants-and-configs'
import { WorkflowIngestionComponent } from './WorkflowIngestionComponent'
import { GITSERVICES } from '../../../app/services/git_services'

const structure = [
  {
    type: 'folder',
    name: 'abbvie_emr',
    files: [
      {
        type: 'folder',
        name: 'configuration',

        files: [
          {
            type: 'folder',
            name: 'dev',
            files: [
              {
                type: 'folder',
                name: 'autosysjobrun',
                files: [],
              },
              {
                type: 'folder',
                name: 'config',
                files: [],
              },
              {
                type: 'folder',
                name: 'parameters',
                files: [],
              },
              {
                type: 'folder',
                name: 'properties',
                files: [],
              },
              {
                type: 'folder',
                name: 'staticfiles',
                files: [],
              },

              {
                type: 'folder',
                name: 'listfiles',
                files: [],
              },
              {
                type: 'folder',
                name: 'schema',
                files: [
                  {
                    type: 'folder',
                    name: 'incomingschema',
                    files: [],
                  },
                ],
              },
            ],
          },
          {
            type: 'folder',
            name: 'qa',
            files: [],
          },

          {
            type: 'folder',
            name: 'prod',
            files: [],
          },
          {
            type: 'file',
            name: 'cdl-market-access-build-abbvie-emr-configuration.yml',
          },
        ],
      },
    ],
  },
]

export const FilesGeneratorComponent = () => {
  var depthPathObj = { depth: 0, refPath: [] }
  let [data, setData] = useState(structure)
  const [show, setShow] = useState(false)
  let [isFileEditData, setIsFileEditData] = useState({
    isTrueParentNode: false,
    folder: '',
    data: {},
  })
  // let [_template, setTemplate] = useState({ level: 0, type: '' })
  const navigate = useNavigate()
  const { dev } = WorkflowJSON

  var findDepth = (obj, key) => {
    if (obj[key]?.name == 'abbvie_emr') {
      depthPathObj.refPath.push(`${obj[key]?.name}`)
      return depthPathObj
    } else {
      depthPathObj.depth++
      depthPathObj.refPath.push(`${obj[key]?.name}`)
      findDepth(obj[key], key)
    }
    console.log('PLAN RETRUN', depthPathObj)
    return depthPathObj
  }

  // var payload = {
  //   type,
  //   content,
  //   action,
  //   repoName,
  //   refPath,
  //   fileName,
  //   targetRepoId,
  // }
  const handleClick = (nodeParam, isFileEdit) => {
    var {
      node: {
        parentNode: { name: folder, type: paraentType },
        type,
        name,
      },
    } = nodeParam
    var payloadType = ''
    var tarObj = {
      isTrueParentNode: false,
      folder: '',
      data: {},
      type: '',
      refPath: '',
      fileName: '',
    }
    var workflowobj = { isWorkflowJson: false }
    if (name.indexOf('workflow.json') >= 0 && isFileEdit) {
      if (
        window.confirm(
          'Have you done with all configuration files creation? Without it pipeline certainly fail!, Click OK to proceed',
        )
      ) {
        workflowobj.isWorkflowJson = true
      }
    }
    // if (
    //   name.indexOf('-workflow.json') >= 0 &&
    //   window.confirm(
    //     'Have you done with all configuration files creation? Without it pipeline certainly fail!, Click OK to proceed',
    //   )
    // ) {
    //   navigate('/workflow-json/workflow-step3')
    // }
    if (type === 'file' && isFileEdit) {
      payloadType = name.substring(name.lastIndexOf('.'), name.length)
      console.log('node', nodeParam)
      depthPathObj.depth = 0
      depthPathObj.refPath = []
      let calcDepth = (() => {
        return findDepth(nodeParam.node, 'parentNode')
      })()
      const parentFolderList = [
        'dev',
        'schema',
        'listfiles',
        'staticfiles',
        'config',
        'parameters',
        'properties',
        'autosysjobrun',
      ]
      const parentParentFolderList = [
        'incomingschema',
        'masterschema',
        'schemachangetracker',
        'schemaremovaltracker',
      ]
      var data = {}

      const ppNodeName = nodeParam.node.parentNode.parentNode.name
      var isTrueParentNode = false
      var rightRefPath = depthPathObj['refPath'].reverse()
      if (
        calcDepth.depth === 3 ||
        (calcDepth.depth === 2 && paraentType === 'folder')
      ) {
        isTrueParentNode = parentFolderList.indexOf(folder) >= 0
        data = FILE_CONSTANT[folder]['data']
        tarObj = {
          ...{
            isTrueParentNode,
            folder,
            data,
            type: payloadType,
            refPath: rightRefPath,
            fileName: name,
          },
          ...workflowobj,
        }
      } else if (calcDepth.depth === 4 && paraentType === 'folder') {
        isTrueParentNode = parentParentFolderList.indexOf(folder) >= 0
        console.log(ppNodeName)
        data = FILE_CONSTANT[ppNodeName]['data']
        tarObj = {
          ...{
            isTrueParentNode,
            folder: ppNodeName,
            data,
            type: payloadType,
            refPath: rightRefPath,
            fileName: name,
          },
          ...workflowobj,
        }
      }

      if (folder === 'properties') {
        // isTrueParentNode = parentParentFolderList.indexOf(folder) >= 0
        data = data['brg_covered_entity_imbruvica_tbl']
      }

      setIsFileEditData(tarObj)
      setShow(true)
    }
  }
  const closeLayer = () => {
    setShow(false)
  }
  const handleUpdate = (state) => {
    console.log(state)
    localStorage.setItem(
      'tree',
      JSON.stringify(state, function (key, value) {
        if (key === 'parentNode' || key === 'id') {
          return null
        }
        return value
      }),
    )
  }
  useLayoutEffect(() => {
    if (!window.localStorage.getItem('tree')) {
      handleUpdate(structure)
    }

    try {
      let savedStructure = JSON.parse(localStorage.getItem('tree'))
      if (savedStructure) {
        setData(savedStructure)
      }
    } catch (err) {
      console.log(err)
    }
  }, [])

    const getRepoData = async () => {
        return await GITSERVICES.GITSERVICES_RESOLVERS.folderResolver()
    }

  useEffect(() => {
    getRepoData().then(({ message, value }) => {
      if (message === 'success') {
        localStorage.setItem('tree', JSON.stringify(value))
        console.log(window.localStorage.getItem('tree'))
         try {
          let savedStructure = JSON.parse(localStorage.getItem('tree'))
          if (savedStructure) {
            setData(savedStructure)
          }
        } catch (err) {
          console.log(err)
        }
      }
    })
  }, [JSON.stringify(isFileEditData)])

  return (
    <>
      <Box>
        {isFileEditData.isTrueParentNode && show ? (
          <Layer
            background="#efefef"
            id="file-generator-layer"
            onEsc={() => setShow(false)}
            onClickOutside={() => setShow(false)}
          >
            <Box
              width="90%"
              height="auto"
              background={'#fff'}
              align="center"
              pad="large"
              class="json-parameter-file-container"
              direction="column"
              margin={'auto'}
            >
              {isFileEditData.isWorkflowJson ? (
                <WorkflowIngestionComponent
                  isFileEditData={isFileEditData}
                  closeFire={() => {
                    closeLayer()
                  }}
                  callback={() => {
                    setIsFileEditData({
                      ...isFileEditData,
                      ...{ isTrueParentNode: false },
                    })
                  }}
                />
              ) : (
                <JSONFormInputComponent
                  isFileEditData={isFileEditData}
                  closeFire={() => {
                    closeLayer()
                  }}
                  callback={() => {
                    setIsFileEditData({
                      ...isFileEditData,
                      ...{ isTrueParentNode: false },
                    })
                  }}
                />
              )}
            </Box>
          </Layer>
        ) : (
          ''
        )}
        <Box
          width="90%"
          height="600px"
          align="center"
          direction="column"
          margin={'auto'}
          className="folder-structure"
        >
        <h2> Generate Config, Parameter, text and workflow.json files to the respective folders</h2>
          <Card
            width="98%"
            height="700px"
            background="#fff"
            margin={'12px'}
            padding="12px"
            align="center"
            justify="center"
            overflow={'auto'}
          >
            <CardHeader
              style={{ color:"#0d479f", width: '80%', lineHeight: '14px', padding:"12px", marginBottom: '24px', fontSize:'13px' }}
            >
              Config files generator, identify what all .properties and .json
              file needs to be created, just use the folder structure and create
              blank files, complete the dev environment  file, other environment
              file will be auto generated. Click on the file name and generate
              the content one by one. Below is the folder structure. <strong>workflow json file generation under DEV folder is important</strong>
              <span style={{fontSize:"2rem"}}>␛</span>escape file name entry
              <span style={{fontSize:"2rem"}}>⎆ enter</span>enter file name entry
            </CardHeader>
            <CardBody
              id="folder-tree"
              style={{ height: '800px', width:"900px", overflowY: 'auto' }}
            >
              {/* <Spinner color={'green'}></Spinner> */}
              <Tree
                data={data}
                onUpdate={handleUpdate}
                onNodeClick={handleClick}
              />
            </CardBody>
            <CardFooter>
              <Button
                primary
                style={{
                  width: '400px',
                  height: '40px',
                  padding: '10px',
                  margin: '10px',
                  fontSize:"10px",
                }}
              >
                If you are done with All config file creation, edit the workflow.json under the DEV FOLDER!!!
              </Button>
            </CardFooter>
          </Card>
        </Box>
      </Box>
    </>
  )
}
