import React, { useState } from 'react'
import validator from '@rjsf/validator-ajv8'
import Form from '@rjsf/core'
import JSONInput from 'react-json-editor-ajrm'
import locale from 'react-json-editor-ajrm/locale/en'
import WorkflowJSONRaw from '../../../assets/data/batch-workflow-template.json'
import WorkflowJSONSchema from '../../../assets/data/batch-workflow-schema.json'
import { Box, Carousel, Text, Button, Anchor, Layer, Spinner } from 'grommet'
import { OnboardingInit } from './OnboardingInit'
import { useEffect } from 'react'
import { containsAny, DOU_JSON_VALIDATOR } from '../../../utils'
import { FilesGeneratorComponent } from './FilesGenerator'
import { useNavigate } from 'react-router-dom'
import { CONSTANTS, FILE_CONSTANT } from '../../../constants-and-configs'
import _ from 'lodash'
import axios from 'axios'
const fullScreenJEStyleObj = {
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100%',
  height: '460px',
  zIndex: 10000,
  background: '#000',
}
export const WorkflowIngestionComponent = ({
  isFileEditData,
  closeFire,
  callback,
}) => {

  const repoName = 'CommercialDatalake-market-access'
  const targetRepoId = 'f2088e90-a063-4621-ab89-a3afe49cf1c5'
  const targetBranchName = 'abbvie_emr_chg000001'
  const navigate = useNavigate()
  const [isSuccess, setIsSuccess] = useState(false)
  const [WorkflowJSON, setWorkflowJSON] = useState(JSONData)
  const [fullScreenJE, setFullScreenJE] = useState(false)
  var [isFileEditObjState, setIsFileEditObjState] = useState(isFileEditData)

  var {
    isTrueParentNode,
    folder,
    data: JSONData,
    type,
    refPath,
    fileName,
  } = isFileEditData

  const updateTemplateData = (data) => {
    let obj = {
      '-d-': `-${CONSTANTS.ENV.DEV}-`,
      'dou-project-name': 'abbvie_emr',
      'dou-market': CONSTANTS.MARKETS['market-access'].KNOWN_NAME,
    }
    let originalData = JSON.stringify(data)
    originalData = originalData.replace(
      /-d-|dou-project-name|dou-market/gi,
      function (matched) {
        return obj[matched]
      },
    )
    let WokflowJSONWithData = JSON.parse(originalData)
    let CopyWokflowJSONWithData = _.cloneDeep(WokflowJSONWithData)
    let jobCount = 3
    if (jobCount > 1) {
      for (let i = 2; i < jobCount; i++) {
        CopyWokflowJSONWithData.dev.steps = _.concat(
          CopyWokflowJSONWithData.dev.steps,
          ...WokflowJSONWithData.dev.steps,
        )
      }
    }
    console.log('WorkflowJSONRaw', CopyWokflowJSONWithData)
    return CopyWokflowJSONWithData
  }

  useEffect(() => {
    const updatedData = updateTemplateData(WorkflowJSONRaw)
    setWorkflowJSON(updatedData)
  }, [])
  return (
    <>
    {isSuccess  ? (
        <Layer background="dark" id="login-layer-auth">

          <Box
            style={{ background: '#fff', borderRadius: '12px' }}
            align="center"
            justify="center"
            width="600px"
            height="300px"
            direction="column"
          >
          {isSuccess === 'loading' ?
          <Box>
          <Spinner size="large" color="green"/>
          <Text color="orange"> Uploading configuration from DEV to QA to PROD folders</Text>
          </Box>
          :
          <Box justify="center" align="center">

          {isSuccess ==='unsuccess' ?
          <Text color="red">  <strong>Uploading Failed, Try again</strong></Text>
          :
          <Text color="green"><strong>Uploaded Successfully</strong></Text>}

            <Button
              primary
              onClick={() => {
                setIsSuccess(false)
                callback()
              }}
            >
              Continue Configuration!!!
            </Button>
            </Box>
            }
          </Box>
        </Layer>
      ):
      ""}
      <Box direction="column" width="100%">
      <Text
          height="30px"
          color="blue"
          style={{cursor:"pointer"}}

            onClick={() => {
              closeFire(false)
            }}
          >Close</Text>
      <Box justify="flex-start" align="center" direction="row" width="100%">
      <Text color="orange" style={{color:"#0d479f", fontSize:"11px", lineHeight:"12px", width:"70%" }}>
          Workflow.json is a workflow container file, which used to contain all
          the config, autosys, arguments and all other references to run any data
          ingestion pipeline, most of the references includes S3 bucket object
          references.{' '}
          <strong>
            Prerequisites are all files are created and uploaded in azure dev
            repos from previous module{' '}
            <Anchor
              color="white"
              label="Recheck"
              onClick={() => {
                navigate('/workflow-json/workflow-step2')
              }}
            />
          </strong>{' '}
          <br></br>
          IMPORTANT: QA and PROD configurations will be auto cloned so no need
          to create workflow for QA and PROD
        </Text>
          <Button
            primary
            style={{
              width: '400px',
              height: '40px',
              padding: '10px',
              margin: '10px',
              fontSize: '1.3rem',
            }}
            onClick={() => {
              navigate('/projects-and-pipelines')
            }}
          >
            Done with the workflow.json Trigger the pipeline to test
          </Button>
        </Box>

        <Box
          width="100%"
          direction="row"
          className="workflow-ingestion-component"
          background="#efefef"
          padding="60px"
          justify="center"
        >
          <Box
            width="100%"
            height="550px"
            overflow={'auto'}
            style={{ margin: '0 auto' }}
          >
            <Form
              schema={WorkflowJSONSchema}
              formData={WorkflowJSON}
              validator={validator}
              onChange={(value) => {
                const { formData } = value
                const countFound = DOU_JSON_VALIDATOR.findReserveKeywords(
                  formData,
                )
                // alert(
                //   `NEED TO MODIFY INGESTION TEMPLATE JSON DATA \n ${countFound} instances need attention`,
                // )
                setWorkflowJSON(formData)
              }}
              onSubmit={async (value) => {
              setIsSuccess('loading');
                const { formData } = value
                const countFound = DOU_JSON_VALIDATOR.findReserveKeywords(
                  formData,
                )

                const stringyJson = JSON.stringify(formData)
                let {
                  isTrueParentNode,
                  folder,
                  data: JSONData,
                  type,
                  refPath,
                  fileName,
                } = isFileEditObjState
                var payload = {
                  type,
                  content: stringyJson,
                  action: 'add',
                  repoName,
                  refPath: `src/${refPath.join('/')}`,
                  fileName,
                  targetRepoId,
                  targetBranchName: `${targetBranchName}`,
                }
                console.log('isFileEditObj', payload)

                var isContainsKeywords = containsAny(
                  stringyJson,
                  FILE_CONSTANT.validator_keywords,
                )
                if (
                  !isContainsKeywords &&
                  window.confirm(
                    'Have you validated all the attributes carefully! Click OK to confirm.',
                  )
                ) {
                  console.log(payload)
                try {
                  const response = await axios.post(
                    'http://10.74.40.62:4000/create-read-update-file',
                    payload,
                  )

                    setIsSuccess(true)
                  }catch{
                   setIsSuccess("unsuccess")
                  }
                } else {
                  alert(
                    'Edit attributes or correct predefined keyword like' +
                      FILE_CONSTANT.validator_keywords.join(','),
                  )
                  return
                }
                setWorkflowJSON(formData)
              }}
            ></Form>
          </Box>
          <Box
            width="45%"
            height="500"
            overflow={'auto'}
            style={{ margin: '24px auto' }}
          >
            <Text>
              Review Workflow JSON with Editor{' '}
              <strong>
                <Anchor
                  label="Full Screen Editor"
                  onClick={() => {
                    setFullScreenJE(!fullScreenJE)
                  }}
                ></Anchor>
              </strong>
            </Text>
            <Box style={fullScreenJE ? fullScreenJEStyleObj : {}}>
              {fullScreenJE ? (
                <Button
                  label="X"
                  primary
                  alignSelf="right"
                  style={{ width: 'auto', height: 'auto', padding: '6px' }}
                  onClick={() => {
                    setFullScreenJE(!fullScreenJE)
                  }}
                />
              ) : (
                ''
              )}

              <JSONInput
                id="back-workflow-J-editor"
                placeholder={WorkflowJSON}
                colors={{
                  string: '#DAA520', // overrides theme colors with whatever color value you want
                }}
                width="100%"
                locale={locale}
                onChange={({ jsObject: value }) => {
                  console.log('VALUE', value)
                  setWorkflowJSON(value)
                }}
              />
            </Box>
          </Box>
        </Box>

      </Box>
    </>
  )
}
