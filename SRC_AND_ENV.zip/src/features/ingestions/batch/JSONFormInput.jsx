import { Box, Layer, Text, Button, Select, Spinner } from 'grommet'
import React from 'react'
import { useState } from 'react'
import validator from '@rjsf/validator-ajv8'
import Form from '@rjsf/core'

import BatchJSONInput from '../../../assets/data/dev/config/batch_ingestion_config.json'
import {TextFileComponent} from '../../../app/components/TextFileComponent'

import {winConfirm, generateDataFromTemplate} from '../../../utils'
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  APP_CONFIG,
  CONSTANTS,
  FILE_CONSTANT,
} from '../../../constants-and-configs'
import { containsAny } from '../../../utils'
import axios from 'axios'

export const JSONFormInputComponent = ({
  isFileEditData,
  closeFire,
  callback,
}) => {
  const navigate = useNavigate()
  const repoName = 'CommercialDatalake-market-access'
  const targetRepoId = 'f2088e90-a063-4621-ab89-a3afe49cf1c5'
  const targetBranchName = 'abbvie_emr_chg000001'
  var {
    isTrueParentNode,
    folder,
    data: JSONData,
    type: fileType,
    refPath,
    fileName,
  } = isFileEditData

  const schema = {
    title: 'UPLOAD CONFIG FILE ',
    description: 'Review or Add',
    type: 'object',
    required: [],
    properties: {},
  }
  const uiSchema = {
    'ui:order': [],
  }

  const [frmSchema, setFrmSchema] = useState({ schema, uiSchema })
  const [formDataInput, setFormDataInput] = useState(JSONData)
  const [optionVal, setOptionVal] = useState('apply edit')
  const [isSuccess, setIsSuccess] = useState(false)
  var [isFileEditObjState, setIsFileEditObjState] = useState(isFileEditData)
  const [action, setAction] = useState('add')

  const schemaGenerator = (data) => {
    const keysArray = Object.keys(data)
    schema.required = keysArray
    uiSchema['ui:order'] = keysArray
    uiSchema['ui:order'].map((item) => {
      schema.properties[item] = {}
      schema.properties[item].type = 'string'
    })
    setFrmSchema({ schema, uiSchema })
    setFormDataInput(data)
  }
  const schemaFolderDataFormulation = (optparam) => {

    const dataForm = {}
    const schemaData = JSONData[optparam]
    setOptionVal(optparam)
    setTimeout(() => {
    if(optparam  !== 'apply edit'){
      setFormDataInput(schemaData)
      }
    }, 500)
  }

  const updateTemplateData = (data, obj) => {
    const mapObj  =  {
       ...obj,
      '{project-name}':CONSTANTS.PROJECT_NAME,
      '{market}': CONSTANTS.MARKETS['market-access'].KNOWN_NAME,
      '{db_market_term}': CONSTANTS.MARKETS['market-access'].DB.db_market_term,
     }
     return generateDataFromTemplate(data,mapObj)
  }
  const readFileWithPath = ({
    fileType,
    content = undefined,
    action = undefined,
    repoName,
    refPath,
    fileName,
    targetRepoId,
    targetBranchName,
  }) => {
     let targetEndpoint = `${CONSTANTS.APIS.DEV_OPS_BASE_URL}/data_onboarding_utility_project/_apis/git/repositories/${targetRepoId}/items?scopePath=src/${refPath}/${fileName}&recursionLevel=None&includeContentMetadata=true&versionDescriptor.version=${targetBranchName}&api-version=7.0`
    return axios.get(targetEndpoint)
   // return response
  }

  const onSubmitTxtFile = async (value) =>{
          console.log(value)
      let { isTrueParentNode,
            folder,
            data: JSONData,
            type,
            refPath,
            fileName,
          } = isFileEditObjState
          var payload = {
            type,
            content:value,
            action: 'add',
            repoName,
            refPath,
            fileName,
            targetRepoId,
            targetBranchName: `${targetBranchName}`,
          }
          const payloadForDEV = {...payload, refPath:`src/${payload.refPath.join('/')}`}
          const qaPath = payload.refPath.map(item => item === 'dev' ? 'qa' : item);
          const payloadForQA = {...payload, refPath:`src/${qaPath.join('/')}`};

          const prodPath = payload.refPath.map(item => item === 'dev' ? 'prod' : item);
          const payloadForPROD = {...payload, refPath:`src/${prodPath.join('/')}`};

          createAndUpdateFiles({payloadForDEV,payloadForQA,payloadForPROD})

      }

      const createAndUpdateFiles = async ({payloadForDEV,payloadForQA,payloadForPROD}) =>{
        setIsSuccess('loading')
        const resDEV = await axios.post(`${APP_CONFIG.API_GATEWAY.BASE_URL}/create-read-update-file`, payloadForDEV);
        const resQA = await axios.post(`${APP_CONFIG.API_GATEWAY.BASE_URL}/create-read-update-file`, payloadForQA);
        const resPROD = await  axios.post(`${APP_CONFIG.API_GATEWAY.BASE_URL}/create-read-update-file`, payloadForPROD);

        axios.all([resDEV,resQA,resPROD]).then(axios.spread((...responses) => {
            const devResponse = responses[0]
            const qaResponse = responses[1]
            const prodResponse = responses[2]

            if (devResponse.data.message === 'success' && qaResponse.data.message === 'success' && prodResponse.data.message === 'success') {
                 setIsSuccess(true)
            }else{
                console.log(devResponse.data.message)
               if (devResponse.data.statusCode!=200 || qaResponse.data.statusCode!=200 || prodResponse.data.statusCode!=200) {
               alert('Error while uploading file in folders. Please contact administrator')
                    setIsSuccess('unsuccess')
               }else{
               setIsSuccess('unsuccess')
               }
            }

         }))
      }
  useEffect(() => {
    if (folder === 'schema' && optionVal !== 'apply edit') {
      //const updatedData = updateTemplateData(formDataInput, {'{env}': 'd'}) //dev
      schemaGenerator(formDataInput)
      schemaFolderDataFormulation('edit')
    }

    let { type: fileType, refPath, fileName } = isFileEditObjState
    let payload = {
      fileType,
      content: undefined,
      action: undefined,
      repoName,
      refPath: refPath.join('/'),
      fileName,
      targetRepoId,
      targetBranchName,
    }

    readFileWithPath(payload).then(({ data }) => {
      console.log(data)
      if(fileType === '.json'){
          if(winConfirm('Target Configuration file is found in repository!!! Would you like to review once again and resubmit?')){
               setFormDataInput(data);
               setAction('edit')
               return
          }else{
              closeFire(false)
              return
          }
      }else if(fileType === ".txt" && optionVal === 'apply edit'){

         setFormDataInput(data)
         setAction('edit')
         return
      }
      payload.content = data
      payload.action = 'read'
      axios.post(`${APP_CONFIG.API_GATEWAY.BASE_URL}/read-file`, payload).then(
        ({ data: readData }) => {
        if(winConfirm('Required file is found in AZURE REPOS would you like to review and resubmit?')){
            setFormDataInput(readData)
            setAction('edit')
        }else{
            closeFire(false)
        }
        },(err) => {
            setFormDataInput(JSONData)
            console.log('ERROR', err)
        },
      )
    },(err)=>{
    setIsSuccess('unsuccess')
    })

  }, [])

  useEffect(() => {
  if(fileType === ".txt" && optionVal === 'apply edit'){

         setFormDataInput(formDataInput)
      }else{
    const updatedData = updateTemplateData(formDataInput, {'{env}': 'd'}) //dev
    schemaGenerator(updatedData)
    }
  }, [JSON.stringify(formDataInput)])

  const onSubmitEventHandler = async (value) => {
      const { formData } = value
      const stringyJson = JSON.stringify(formData)
      let {
        isTrueParentNode,
        folder,
        data: JSONData,
        type,
        refPath,
        fileName,
      } = isFileEditObjState
      var payload = {
        type,
        content:formData,
        action: action,
        repoName,
        refPath,
        fileName,
        targetRepoId,
        targetBranchName: `${targetBranchName}`,
      }
      console.log('isFileEditObj', payload)
      setIsSuccess('loading')
      var isContainsKeywords = containsAny(
        stringyJson,
        FILE_CONSTANT.validator_keywords,
      )
      if (
        !isContainsKeywords &&
        window.confirm(
          'Have you validated all the attributes carefully! Click OK to confirm.',
        )
      ) {
        console.log(payload)

//     if (payload.refPath.indexOf('/properties/') >= 0) {
//       let addedPropContent = {
//         mhcd_immun_mkt_strt_pak_excptn_tbl: formData,
//       }
//       payload.content = JSON.stringify(addedPropContent)
//     }

//                 const response = await axios.post(
//                   `${APP_CONFIG.API_GATEWAY.BASE_URL}/create-read-update-file`,
//                   payload,
//                 )
//                 if (response.message === 'success') {
//                   setIsSuccess(true)
//                 }
        //DEV payload
        let payloadForDEV = (payload.refPath.indexOf('properties') >= 0) ? {...payload, content:JSON.stringify({brg_covered_entity_imbruvica_tbl: formData}), refPath:`src/${payload.refPath.join('/')}`} : {...payload, content:JSON.stringify(formData), refPath:`src/${payload.refPath.join('/')}`};

        //QA payload
        let qaPath = payload.refPath.map(item => item === 'dev' ? 'qa' : item);
        let qaContent= updateTemplateData(formData,{'-d-': '-q-'}) // -d-
        let payloadForQA = (payload.refPath.indexOf('properties') >= 0) ? {...payload, content:JSON.stringify({brg_covered_entity_imbruvica_tbl: qaContent}), refPath:`src/${qaPath.join('/')}`} : {...payload, content:JSON.stringify(qaContent) ,refPath:`src/${qaPath.join('/')}`};

         //PROD payload
        let prodPath = payload.refPath.map(item => item === 'dev' ? 'prod' : item);
        let prodContent= updateTemplateData(formData,{'-d-': '-p-'}) //-d-
        let payloadForPROD = (payload.refPath.indexOf('properties') >= 0) ? {...payload, content:JSON.stringify({brg_covered_entity_imbruvica_tbl: prodContent}), refPath:`src/${prodPath.join('/')}`} : {...payload, content:JSON.stringify(prodContent) ,refPath:`src/${prodPath.join('/')}`};

        createAndUpdateFiles({payloadForDEV,payloadForQA,payloadForPROD})
      } else {
        alert(
          'Edit, attributes or correct predefined keyword like' +
            FILE_CONSTANT.validator_keywords.join(','),
        )
        return
      }
    }
  return (
    <>

      {isSuccess  ? (
        <Layer background="dark" id="login-layer-auth">

          <Box
            style={{ background: '#fff', borderRadius: '12px' }}
            align="center"
            justify="center"
            width="600px"
            height="300px"
            direction="column"
          >
          {isSuccess === 'loading' ?
          <Box>
          <Spinner size="large" color="green"/>
          <Text color="orange"> Uploading configuration from DEV to QA to PROD folders</Text>
          </Box>
          :
          <Box justify="center" align="center">

          {isSuccess ==='unsuccess' ?
          <Text color="red">  <strong>Uploading Failed, Try again</strong></Text>
          :
          <Text color="green"><strong>Uploaded Successfully</strong></Text>}

            <Button
              primary
              onClick={() => {
                setIsSuccess(false)
                callback()
              }}
            >
              Continue Configuration!!!
            </Button>
            </Box>
            }
          </Box>
        </Layer>
      ) : (
        <Box
          width="100%"
          style={{padding:"24px", paddingTop:"5px"}}
          className="json-parameter-file-container"
          margin="0px"
          padding="0px"
        >
        <Text
          height="30px"
          color="blue"
          style={{cursor:"pointer"}}

            onClick={() => {
              closeFire(false)
            }}
          >Close</Text>
          <Box justify="flex-start" align="center">
          <Text style={{ fontSize:"12px", color:"crimson"}}><strong>Target file path </strong>:    <span style={{color:"blue"}}>{`${refPath.join('/')}/${fileName}`}</span></Text>
            {folder === 'schema' ? (
              <Select
                primary
                value={optionVal}
                onChange={({ option }) => {
                  schemaFolderDataFormulation(option)
                }}
                options={['apply edit', 'covered', 'contracted', 'num_rx']}
              />
            ) : (
              ''
            )}
          </Box>
          { isFileEditObjState.type === '.txt'  ?
          <TextFileComponent isEdit fileContent={JSON.stringify(formDataInput)} onCallbackSubmit={onSubmitTxtFile}  />
          :
          <Form
            schema={frmSchema.schema}
            formData={formDataInput}
            uiSchema={frmSchema.uiSchema}
            validator={validator}
            onSubmit={onSubmitEventHandler}
          />
          }
        </Box>
      )}
    </>
  )
}
