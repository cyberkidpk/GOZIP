import React from 'react'
import validator from '@rjsf/validator-ajv8'
import Form from '@rjsf/core'
import JSONInput from 'react-json-editor-ajrm'
import locale from 'react-json-editor-ajrm/locale/en'
import WorkflowJSON from '../../../assets/data/batch-workflow-template.json'
import WorkflowJSONSchema from '../../../assets/data/batch-workflow-schema.json'
import { Box, Carousel, Text } from 'grommet'
import { OnboardingInit } from './OnboardingInit'
import { useEffect } from 'react'
import { DOU_JSON_VALIDATOR } from '../../../utils'
import { FilesGeneratorComponent } from './FilesGenerator'
import { Outlet } from 'react-router-dom'

export const WorkflowOutlet = () => {
  useEffect(() => {
    //const countFound = DOU_JSON_VALIDATOR.findReserveKeywords(WorkflowJSON)
  }, [JSON.stringify(WorkflowJSON)])
  return (
    <>
      <Box
        width="100%"
        className="workflow-ingestion-component"
        background="#efefef"
        padding="12px"
        justify="center"
      >
        <Outlet />
      </Box>
    </>
  )
}
