import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import { fetchUserInfo } from './loginAPI'

const initialState = {
  isAuthenticated: false,
  isAuthorize: false,
  userInfo: {},
  status: 'idle',
}

//loading: 'idle' | 'pending' | 'succeeded' | 'failed'

export const getUserInfoAsync = createAsyncThunk(
  'login/authorise',
  async () => {
    const response = await fetchUserInfo()
    // The value we return becomes the `fulfilled` action payload
    return response.data
  },
)

export const loginSlice = createSlice({
  name: 'loginInfo',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getUserInfoAsync.pending, (state) => {
        state.isAuthenticated = false
        state.isAuthorize = false
        state.status = 'loading'
      })
      .addCase(getUserInfoAsync.fulfilled, (state, action) => {
        state.status = 'succeeded'
        state.isAuthenticated = true
        state.isAuthorize = true
        state.userInfo = action.payload
      })
  },
})

export const loginInfo = (state) => state.loginInfo

export default loginSlice.reducer
