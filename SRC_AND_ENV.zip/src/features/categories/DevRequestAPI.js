import axios from 'axios'
import { CONSTANTS } from '../../constants-and-configs'

// A mock function to mimic making an async request for data
const targetEndPoint =
  CONSTANTS.APIS.DEV_OPS_BASE_URL + CONSTANTS.APIS.GET_SUFFIX.PROJECTS
export function fetchUserInfo() {
  return new Promise((resolve) =>
    setTimeout(
      () =>
        resolve({
          data: { name: 'Global User', email: '', userId: 'GBLUSERPX' },
        }),
      500,
    ),
  )
}
