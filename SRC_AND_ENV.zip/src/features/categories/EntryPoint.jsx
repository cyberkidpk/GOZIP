import { Button, Box, Text, Layer, CheckBox } from 'grommet'
import React, { useState } from 'react'
import { useEffect } from 'react'
import { useSelector } from 'react-redux'
import { loginInfo } from '../login/loginSlice'
const EntryPointState ={
    isNew:false,
    ingestion:{
    sqoop:{},
    batch:{}
}
}
const RequestFormFields = ['project_type']
const schema = {
  type: 'object',
  required: RequestFormFields,
  properties: {
    project_type: {
      type: 'boolean',
      title: 'Is Existing Project',
      anyOf: [true, false],
    },
  },
}
const uiSchema = {
  system_src: {
    'ui:widget': 'checkbox',
  },
}
export const EntryPoint = () => {
  const [formDataInput, setFormDataInput] = useState({
    project_type: true,
  })
  const userInfoData = useSelector(loginInfo)
  useEffect(() => {
    console.log('UserInfoData', userInfoData)
  })
  return (
    <Layer background="dark" id="login-layer-auth">
      <Box direction="row" pad="large" justify="center">
        <Text color="#ccc">Is New Project</Text>{' '}
        <CheckBox checked style={{ marginTop: '-10px' }}></CheckBox>
      </Box>
      <Box className="entry-point">
        <Button primary color="white" href="#" title="No Action">
        <Text>PHASE -II Deliverable,</Text>
          <h2> Click here for sqoop ingestion.</h2>
          <Text size="small" color="orange">
            {' '}
            See all the projects and pipelines that belongs to you and you can
            perform ingestion of .prm as well as modifiation of the file. You
            also have ablity to trigger the pipeline after your satisfacion.
          </Text>
        </Button>
        <Button primary color="white" href="/entry-point-dev-request">
          <Text color="orange">BATCH DATA ONBOARDING</Text>
          <h2>Click here for Batch ingestion.</h2>
        </Button>
      </Box>
      <Text size="small" color="#d3cfbece" style={{ fontSize: '12px' }}>
        <ul>
          <div>Prerequisites</div>
          <li>
            All the data onboarding approvals are received & all documentations
            are review & approved.
          </li>
          <li>Barebore pipeline project has been created already</li>
          <li>Developers are aware of ingestion parameters</li>
          <li>
            If any table creation or any other related information required,
            developer seek outside support
          </li>
        </ul>
      </Text>
    </Layer>
  )
}
