import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Image,
  Text,
  TextInput,
  // Form,
  FormField,
  Button,
  Spinner,
  RadioButtonGroup,
  Layer,
} from 'grommet'

import validator from '@rjsf/validator-ajv8'
import Form from '@rjsf/core'

import '../../assets/css/_sqoop.scss'
import * as GITSERVICES from '../../app/services/git_services'
import { CONSTANTS } from '../../constants-and-configs'
const RequestFormFields = [
  'change_request',
  'project_name',
  'jobs_no',
  'system_src',
  'feature_branch_name',
]
const schema = {
  title: 'Project Requirement Parameters',
  description:
    'You must have completed change request ID and feature branch created at respective market',
  type: 'object',
  required: RequestFormFields,
  properties: {
    change_request: {
      type: 'string',
      title: 'Enter Change Request',
    },
    project_name: {
      type: 'string',
      title: 'Enter Project Name',
    },
    feature_branch_name: {
      type: 'string',
      title: 'Predicted Feature Branch, leave it blank to run on dev branch',
    },
    jobs_no: {
      type: 'number',
      title: 'No of jobs required(assuming there is only one job)',
      minimum: 1,
      default: 1,
    },
    system_src: {
      type: 'string',
      title: 'Source Market',
      anyOf: [
        {
          type: 'string',
          title: 'Market Access 360',
          enum: ['market-access'],
        },
        {
          type: 'string',
          title: 'HCP360',
          enum: ['hcp360'],
        },
        {
          type: 'string',
          title: 'Marketing',
          enum: ['marketing'],
        },
        {
          type: 'string',
          title: 'Syndicated',
          enum: ['syndicated'],
        },
        {
          type: 'string',
          title: 'OPS',
          enum: ['operations'],
        },
      ],
    },
  },
}

const uiSchema = {
  system_src: {
    'ui:widget': 'select',
  },
  feature_branch_name: {
    'ui:readonly': true,
  },
  // 'ui:order': RequestFormFields,
}

// uiSchema['ui:order'].map((item) => {
//   if (item !== 'sqoop_jobs_no' || item !== 'system_src') {
//     schema.properties[item] = {}
//     schema.properties[item].type = 'string'
//   }
// })

console.log('scheme', schema)
const defaultFormData = {
  jobs_no: 1,
  system_src: 'market-access',
  change_request: 'chg000001',
  project_name: 'abbvie_emr',
  feature_branch_name: 'abbvie_emr_chg000001',
}
export { DevRequestForm }

function DevRequestForm() {
  const [value, setValue] = useState({ name: 'a', email: 'b' })
  const [varified, setVerified] = useState(false)
  const [resStatus, setResStatus] = useState()
  const [formDataInput, setFormDataInput] = useState(defaultFormData)

  const message =
    value.name && value.email && value.name[0] !== value.email[0]
      ? 'Mismatched first character'
      : undefined

  const navigate = useNavigate()
  const formSubmitEventHandler = async ({
    formData: { system_src, feature_branch_name },
  }) => {
    const response = await GITSERVICES.GITSERVICES_RESOLVERS.featureBranchResolver(
      system_src,
      feature_branch_name,
    )
    if (response.message.toLowerCase() === 'success' && response.data.value) {
      setVerified(true)
      setResStatus('success')
    } else {
      setVerified(true)
      setResStatus('failed')
      console.log('error')
    }
    console.log('onsubmit response', response)
  }

  const formOnChangeHandler = (nextValue) => {
    //update feature_branch_name
    setFormDataInput({
      ...nextValue.formData,
      feature_branch_name: `${nextValue.formData.project_name}_${nextValue.formData.change_request}`,
    })
  }

  useEffect(() => {}, [])
  return (
    <Layer background="dark" id="login-layer-auth">
      {varified ? (
        <Box
          style={{ background: '#fff', borderRadius: '12px' }}
          align="center"
          justify="center"
          width="600px"
          height="300px"
          direction="column"
        >
          {resStatus === 'success' ? (
            <>
              <Text size="medium" color="green" align="center" justify="center">
                <strong>Verified</strong> Feature Branch{' '}
                {formDataInput.feature_branch_name} exists.<br></br>
              </Text>
              <Button
                primary
                onClick={() => {
                  navigate('/workflow-json')
                }}
              >
                Proceed Further
              </Button>
            </>
          ) : (
            <>
              {' '}
              <Text size="medium" color="red">
                <strong>Error</strong>
                <br />
                Feature branch {formDataInput.feature_branch_name} does not
                exists. or you provided a wrong project name, market or change request no.<br></br>
              </Text>
              <Button
                primary
                onClick={() => {
                  setVerified(false)
                  setFormDataInput(defaultFormData)
                }}
              >
                Back
              </Button>
            </>
          )}
        </Box>
      ) : (
        <Box
          style={{ background: '#fff' }}
          align="center"
          justify="center"
          width="600px"
          className="dev-request"
        >
          <Box gap="small">
            {
              // navigate("/review-ingestion")
            }
            <Form
              schema={schema}
              uiSchema={uiSchema}
              formData={formDataInput}
              validator={validator}
              onChange={formOnChangeHandler}
              onSubmit={formSubmitEventHandler}
            />
          </Box>
        </Box>
      )}
    </Layer>
  )
}
