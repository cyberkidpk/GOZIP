import axios from 'axios'
import { CONSTANTS } from '../../constants-and-configs'

const token = '7imqmsyfz5uqjfh3bo7pnt4vj44kf3rspor6o6rfe2bz7qeccpna'

if (token) {
  axios.defaults.headers.common = {
    Authorization: 'Basic ' + btoa('' + ':' + token),
  }
}
// A mock function to mimic making an async request for data
const targetEndPoint =
  CONSTANTS.APIS.DEV_OPS_BASE_URL + CONSTANTS.APIS.GET_SUFFIX.PROJECTS
export function fetchProjects() {
  return axios.get(targetEndPoint)
}
