import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import _ from 'lodash'
import {
  Box,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Image,
  Text,
  TextInput,
  Form,
  Button,
  Anchor,
  Spinner,
  DataTable,
} from 'grommet'
import axios from 'axios'

import '../../assets/css/_home.scss'

// import { columns, data, DATA } from '../../assets/data'
// import useFetchData from '../../app/hooks/curd'
// import { APP_CONFIG, CONSTANTS } from '../../constants-and-configs'
// import { forEach } from 'lodash'
import { DIUAccordion } from '../../app/components/accordion'
import { getProjectsAsync, projectsValue } from './projectsAndPipelinesSlice'

// const groupColumns = [...columns]
// const first = groupColumns[0]
// groupColumns[0] = { ...groupColumns[1] }
// groupColumns[1] = { ...first }
// groupColumns[0].footer = groupColumns[1].footer
// delete groupColumns[1].footer
export { ProjectsAndPipelines }

function ProjectsAndPipelines() {
  const projectsValueData = useSelector(projectsValue)
  const dispatch = useDispatch()

  const [dataValue, setDataValue] = useState([])

  useEffect(() => {
    window.localStorage.setItem('review', null)
    window.localStorage.setItem('pro-name', null)
    console.log('DAAAAAAAAATAAAAAAAAAAAAAAAAAA', projectsValueData)
    if (projectsValueData && projectsValueData.length) {
      console.log(projectsValueData)
      setDataValue(projectsValueData)

      const mockData = [
        {
          name: 'Alan',
          project: 'CDL2.0 Gold',
          date: '',
          percent: 0,
          requeststatus: 'Not Started',
          addparameters: 0,
        },
      ]
      //setDataValue(value)
    } else if (!projectsValueData || !projectsValueData.length) {
      dispatch(getProjectsAsync([]))
    }
  }, [projectsValueData.length, dataValue.length])

  return (
    <Box style={{ background: '#fff' }} align="left" justify="center">
      <Text style={{ background: '#656d77', color: '#efefef' }}>
        PROJECTS AND PIPELINES :{' '}
        <Button
          size="small"
          primary
          href="/projects-and-pipelines"
          style={{ fontSize: '.55rem', padding: '3px', margin: '6px' }}
        >
          Refresh Statuses
        </Button>
      </Text>

      <Box align="top" direction="row" justify="center" gap="small">
        {<DIUAccordion data={dataValue} />}

        {/* <DataTable
     columns={groupColumns}
      data={dataValue}
      primaryKey={false}
      groupBy={{
        property: 'project',
        expand: expandedGroups,
        onExpand: setExpandedGroups,
      }}
      sortable
    /> */}
      </Box>
    </Box>
  )
}
